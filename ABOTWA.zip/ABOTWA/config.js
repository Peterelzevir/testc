// config.js - Configuration file for the bot

const config = {
    // Bot Owner Information
    owner: {
        name: "YourName",
        number: "628xxxxxxxxxx", // Format: country code without +
        numberWithPlus: "+628xxxxxxxxxx", // Format: with + for display
    },
    
    // Bot Information
    bot: {
        name: "𝕎𝔸 𝕂𝔼ℂ𝔼 𝔹𝕆𝕋",
        version: "1.0.0",
        prefix: "!",
        emoji: "🤖",
    },
    
    // Database and Storage
    database: {
        type: "json", // Currently only JSON supported
        path: "./database.json",
    },
    
    // Catalog Settings
    catalog: {
        title: "📱 𝔻𝕀𝔾𝕀𝕋𝔸𝕃 𝕊𝕋𝕆ℝ𝔼 📱",
        description: "Berikut adalah list produk yang tersedia:",
        footer: "Pilih produk untuk melakukan pembelian",
        buttonText: "Lihat Katalog",
    },
    
    // Catalog Items (PPOB & Game TopUps)
    catalogItems: [
        {
            category: "PULSA",
            items: [
                // Telkomsel
                { name: "Pulsa Telkomsel 5K", price: 6000, code: "T5" },
                { name: "Pulsa Telkomsel 10K", price: 11000, code: "T10" },
                { name: "Pulsa Telkomsel 15K", price: 16000, code: "T15" },
                { name: "Pulsa Telkomsel 20K", price: 21000, code: "T20" },
                { name: "Pulsa Telkomsel 25K", price: 26000, code: "T25" },
                { name: "Pulsa Telkomsel 30K", price: 31000, code: "T30" },
                { name: "Pulsa Telkomsel 40K", price: 41000, code: "T40" },
                { name: "Pulsa Telkomsel 50K", price: 51000, code: "T50" },
                { name: "Pulsa Telkomsel 75K", price: 76000, code: "T75" },
                { name: "Pulsa Telkomsel 100K", price: 100500, code: "T100" },
                { name: "Pulsa Telkomsel 150K", price: 150500, code: "T150" },
                { name: "Pulsa Telkomsel 200K", price: 200500, code: "T200" },
                
                // Indosat
                { name: "Pulsa Indosat 5K", price: 6000, code: "I5" },
                { name: "Pulsa Indosat 10K", price: 11000, code: "I10" },
                { name: "Pulsa Indosat 12K", price: 13000, code: "I12" },
                { name: "Pulsa Indosat 15K", price: 16000, code: "I15" },
                { name: "Pulsa Indosat 20K", price: 21000, code: "I20" },
                { name: "Pulsa Indosat 25K", price: 26000, code: "I25" },
                { name: "Pulsa Indosat 30K", price: 31000, code: "I30" },
                { name: "Pulsa Indosat 50K", price: 51000, code: "I50" },
                { name: "Pulsa Indosat 60K", price: 61000, code: "I60" },
                { name: "Pulsa Indosat 80K", price: 81000, code: "I80" },
                { name: "Pulsa Indosat 100K", price: 100500, code: "I100" },
                { name: "Pulsa Indosat 150K", price: 150500, code: "I150" },
                { name: "Pulsa Indosat 200K", price: 200500, code: "I200" },
                
                // XL
                { name: "Pulsa XL 5K", price: 6000, code: "X5" },
                { name: "Pulsa XL 10K", price: 11000, code: "X10" },
                { name: "Pulsa XL 15K", price: 16000, code: "X15" },
                { name: "Pulsa XL 25K", price: 26000, code: "X25" },
                { name: "Pulsa XL 30K", price: 31000, code: "X30" },
                { name: "Pulsa XL 50K", price: 51000, code: "X50" },
                { name: "Pulsa XL 100K", price: 100500, code: "X100" },
                { name: "Pulsa XL 200K", price: 200500, code: "X200" },
                
                // Axis
                { name: "Pulsa Axis 5K", price: 6000, code: "A5" },
                { name: "Pulsa Axis 10K", price: 11000, code: "A10" },
                { name: "Pulsa Axis 15K", price: 16000, code: "A15" },
                { name: "Pulsa Axis 25K", price: 26000, code: "A25" },
                { name: "Pulsa Axis 50K", price: 51000, code: "A50" },
                { name: "Pulsa Axis 100K", price: 100500, code: "A100" },
                
                // Tri (3)
                { name: "Pulsa Tri 5K", price: 6000, code: "H5" },
                { name: "Pulsa Tri 10K", price: 11000, code: "H10" },
                { name: "Pulsa Tri 15K", price: 16000, code: "H15" },
                { name: "Pulsa Tri 20K", price: 21000, code: "H20" },
                { name: "Pulsa Tri 30K", price: 31000, code: "H30" },
                { name: "Pulsa Tri 50K", price: 51000, code: "H50" },
                { name: "Pulsa Tri 100K", price: 100500, code: "H100" },
                { name: "Pulsa Tri 150K", price: 150500, code: "H150" },
                { name: "Pulsa Tri 200K", price: 200500, code: "H200" },
                
                // Smartfren
                { name: "Pulsa Smartfren 5K", price: 6000, code: "S5" },
                { name: "Pulsa Smartfren 10K", price: 11000, code: "S10" },
                { name: "Pulsa Smartfren 20K", price: 21000, code: "S20" },
                { name: "Pulsa Smartfren 25K", price: 26000, code: "S25" },
                { name: "Pulsa Smartfren 50K", price: 51000, code: "S50" },
                { name: "Pulsa Smartfren 60K", price: 61000, code: "S60" },
                { name: "Pulsa Smartfren 100K", price: 100500, code: "S100" },
                { name: "Pulsa Smartfren 150K", price: 150500, code: "S150" },
                { name: "Pulsa Smartfren 200K", price: 200500, code: "S200" },
                
                // By.U
                { name: "Pulsa By.U 5K", price: 6000, code: "BY5" },
                { name: "Pulsa By.U 10K", price: 11000, code: "BY10" },
                { name: "Pulsa By.U 20K", price: 21000, code: "BY20" },
                { name: "Pulsa By.U 50K", price: 51000, code: "BY50" },
                { name: "Pulsa By.U 100K", price: 100500, code: "BY100" }
            ]
        },
        {
            category: "PAKET DATA",
            items: [
                // Telkomsel
                { name: "Telkomsel Data 1GB 1 Hari", price: 10000, code: "TD1H" },
                { name: "Telkomsel Data 1GB 3 Hari", price: 10000, code: "TD1_3" },
                { name: "Telkomsel Data 1GB 7 Hari", price: 12000, code: "TD1" },
                { name: "Telkomsel Data 2GB 7 Hari", price: 22000, code: "TD2" },
                { name: "Telkomsel Data 3GB 7 Hari", price: 30000, code: "TD3_7" },
                { name: "Telkomsel Data 5GB 7 Hari", price: 40000, code: "TD5_7" },
                { name: "Telkomsel Data 5GB 30 Hari", price: 52000, code: "TD5" },
                { name: "Telkomsel Data 8GB 30 Hari", price: 72000, code: "TD8" },
                { name: "Telkomsel Data 10GB 30 Hari", price: 82000, code: "TD10" },
                { name: "Telkomsel Data 15GB 30 Hari", price: 110000, code: "TD15" },
                { name: "Telkomsel Data 25GB 30 Hari", price: 150000, code: "TD25" },
                
                // Indosat
                { name: "Indosat Data 1GB 1 Hari", price: 8000, code: "ID1H" },
                { name: "Indosat Data 1GB 7 Hari", price: 11000, code: "ID1" },
                { name: "Indosat Data 2GB 7 Hari", price: 21000, code: "ID2" },
                { name: "Indosat Data 3GB 7 Hari", price: 28000, code: "ID3_7" },
                { name: "Indosat Data 5GB 7 Hari", price: 35000, code: "ID5_7" },
                { name: "Indosat Data 7GB 30 Hari", price: 49000, code: "ID7" },
                { name: "Indosat Data 10GB 30 Hari", price: 69000, code: "ID10" },
                { name: "Indosat Data 15GB 30 Hari", price: 89000, code: "ID15" },
                { name: "Indosat Data 25GB 30 Hari", price: 125000, code: "ID25" },
                { name: "Indosat Data 40GB 30 Hari", price: 150000, code: "ID40" },
                
                // XL
                { name: "XL Data 1GB 1 Hari", price: 8000, code: "XD1H" },
                { name: "XL Data 1GB 7 Hari", price: 10000, code: "XD1" },
                { name: "XL Data 3GB 7 Hari", price: 25000, code: "XD3_7" },
                { name: "XL Data 5GB 7 Hari", price: 38000, code: "XD5_7" },
                { name: "XL Data 10GB 30 Hari", price: 65000, code: "XD10" },
                { name: "XL Data 15GB 30 Hari", price: 85000, code: "XD15" },
                { name: "XL Data 25GB 30 Hari", price: 120000, code: "XD25" },
                
                // Axis
                { name: "Axis Data 1GB 1 Hari", price: 7000, code: "AD1H" },
                { name: "Axis Data 2GB 5 Hari", price: 14000, code: "AD2_5" },
                { name: "Axis Data 5GB 15 Hari", price: 35000, code: "AD5_15" },
                { name: "Axis Data 8GB 30 Hari", price: 55000, code: "AD8" },
                { name: "Axis Data 16GB 30 Hari", price: 85000, code: "AD16" },
                
                // Tri (3)
                { name: "Tri Data 1GB 1 Hari", price: 6000, code: "HD1H" },
                { name: "Tri Data 2GB 3 Hari", price: 12000, code: "HD2_3" },
                { name: "Tri Data 3GB 7 Hari", price: 20000, code: "HD3_7" },
                { name: "Tri Data 8GB 30 Hari", price: 45000, code: "HD8" },
                { name: "Tri Data 15GB 30 Hari", price: 75000, code: "HD15" },
                { name: "Tri Data 25GB 30 Hari", price: 100000, code: "HD25" },
                
                // Smartfren
                { name: "Smartfren Data 1GB 1 Hari", price: 6000, code: "SD1H" },
                { name: "Smartfren Data 2GB 7 Hari", price: 15000, code: "SD2_7" },
                { name: "Smartfren Data 8GB 30 Hari", price: 45000, code: "SD8" },
                { name: "Smartfren Data 16GB 30 Hari", price: 75000, code: "SD16" },
                { name: "Smartfren Data 30GB 30 Hari", price: 100000, code: "SD30" },
                
                // By.U
                { name: "By.U Data 1GB 1 Hari", price: 8000, code: "BYD1H" },
                { name: "By.U Data 3GB 7 Hari", price: 25000, code: "BYD3_7" },
                { name: "By.U Data 6GB 30 Hari", price: 45000, code: "BYD6" },
                { name: "By.U Data 10GB 30 Hari", price: 65000, code: "BYD10" }
            ]
        },
        {
            category: "E-MONEY",
            items: [
                // DANA
                { name: "DANA 10K", price: 11000, code: "DN10" },
                { name: "DANA 20K", price: 21000, code: "DN20" },
                { name: "DANA 25K", price: 26000, code: "DN25" },
                { name: "DANA 30K", price: 31000, code: "DN30" },
                { name: "DANA 40K", price: 41000, code: "DN40" },
                { name: "DANA 50K", price: 51000, code: "DN50" },
                { name: "DANA 75K", price: 76000, code: "DN75" },
                { name: "DANA 100K", price: 101000, code: "DN100" },
                { name: "DANA 150K", price: 151000, code: "DN150" },
                { name: "DANA 200K", price: 201000, code: "DN200" },
                { name: "DANA 250K", price: 251000, code: "DN250" },
                { name: "DANA 300K", price: 301000, code: "DN300" },
                { name: "DANA 400K", price: 401000, code: "DN400" },
                { name: "DANA 500K", price: 501000, code: "DN500" },
                
                // OVO
                { name: "OVO 10K", price: 11000, code: "OV10" },
                { name: "OVO 20K", price: 21000, code: "OV20" },
                { name: "OVO 25K", price: 26000, code: "OV25" },
                { name: "OVO 30K", price: 31000, code: "OV30" },
                { name: "OVO 40K", price: 41000, code: "OV40" },
                { name: "OVO 50K", price: 51000, code: "OV50" },
                { name: "OVO 75K", price: 76000, code: "OV75" },
                { name: "OVO 100K", price: 101000, code: "OV100" },
                { name: "OVO 150K", price: 151000, code: "OV150" },
                { name: "OVO 200K", price: 201000, code: "OV200" },
                
                // GoPay
                { name: "GoPay 10K", price: 11000, code: "GP10" },
                { name: "GoPay 20K", price: 21000, code: "GP20" },
                { name: "GoPay 25K", price: 26000, code: "GP25" },
                { name: "GoPay 30K", price: 31000, code: "GP30" },
                { name: "GoPay 50K", price: 51000, code: "GP50" },
                { name: "GoPay 75K", price: 76000, code: "GP75" },
                { name: "GoPay 100K", price: 101000, code: "GP100" },
                { name: "GoPay 150K", price: 151000, code: "GP150" },
                { name: "GoPay 200K", price: 201000, code: "GP200" },
                
                // ShopeePay
                { name: "ShopeePay 10K", price: 11000, code: "SP10" },
                { name: "ShopeePay 20K", price: 21000, code: "SP20" },
                { name: "ShopeePay 30K", price: 31000, code: "SP30" },
                { name: "ShopeePay 50K", price: 51000, code: "SP50" },
                { name: "ShopeePay 100K", price: 101000, code: "SP100" },
                { name: "ShopeePay 150K", price: 151000, code: "SP150" },
                { name: "ShopeePay 200K", price: 201000, code: "SP200" },
                
                // LinkAja
                { name: "LinkAja 10K", price: 11000, code: "LA10" },
                { name: "LinkAja 20K", price: 21000, code: "LA20" },
                { name: "LinkAja 50K", price: 51000, code: "LA50" },
                { name: "LinkAja 100K", price: 101000, code: "LA100" },
                { name: "LinkAja 200K", price: 201000, code: "LA200" }
            ]
        },
        {
            category: "GAME TOPUP",
            items: [
                // Mobile Legends
                { name: "ML - 3 Diamonds", price: 1500, code: "ML3" },
                { name: "ML - 5 Diamonds", price: 2000, code: "ML5" },
                { name: "ML - 11 Diamonds", price: 3500, code: "ML11" },
                { name: "ML - 17 Diamonds", price: 5000, code: "ML17" },
                { name: "ML - 25 Diamonds", price: 7500, code: "ML25" },
                { name: "ML - 40 Diamonds", price: 11000, code: "ML40" },
                { name: "ML - 53 Diamonds", price: 14000, code: "ML53" },
                { name: "ML - 77 Diamonds", price: 20000, code: "ML77" },
                { name: "ML - 154 Diamonds", price: 40000, code: "ML154" },
                { name: "ML - 217 Diamonds", price: 56000, code: "ML217" },
                { name: "ML - 256 Diamonds", price: 67000, code: "ML256" },
                { name: "ML - 367 Diamonds", price: 93000, code: "ML367" },
                { name: "ML - 503 Diamonds", price: 125000, code: "ML503" },
                { name: "ML - 774 Diamonds", price: 195000, code: "ML774" },
                { name: "ML - 1708 Diamonds", price: 415000, code: "ML1708" },
                { name: "ML - Starlight Member", price: 140000, code: "MLSL" },
                { name: "ML - Starlight Plus", price: 300000, code: "MLSLP" },
                
                // Free Fire
                { name: "FF - 5 Diamonds", price: 1000, code: "FF5" },
                { name: "FF - 12 Diamonds", price: 2000, code: "FF12" },
                { name: "FF - 50 Diamonds", price: 8000, code: "FF50" },
                { name: "FF - 70 Diamonds", price: 10000, code: "FF70" },
                { name: "FF - 100 Diamonds", price: 15000, code: "FF100" },
                { name: "FF - 140 Diamonds", price: 20000, code: "FF140" },
                { name: "FF - 210 Diamonds", price: 30000, code: "FF210" },
                { name: "FF - 355 Diamonds", price: 50000, code: "FF355" },
                { name: "FF - 425 Diamonds", price: 60000, code: "FF425" },
                { name: "FF - 500 Diamonds", price: 70000, code: "FF500" },
                { name: "FF - 720 Diamonds", price: 100000, code: "FF720" },
                { name: "FF - 1000 Diamonds", price: 135000, code: "FF1000" },
                { name: "FF - 1440 Diamonds", price: 195000, code: "FF1440" },
                { name: "FF - 2000 Diamonds", price: 270000, code: "FF2000" },
                { name: "FF - Member Mingguan", price: 30000, code: "FFW" },
                { name: "FF - Member Bulanan", price: 140000, code: "FFM" },
                
                // PUBG Mobile
                { name: "PUBG - 60 UC", price: 15000, code: "PG60" },
                { name: "PUBG - 120 UC", price: 29000, code: "PG120" },
                { name: "PUBG - 240 UC", price: 58000, code: "PG240" },
                { name: "PUBG - 600 UC", price: 145000, code: "PG600" },
                { name: "PUBG - 1200 UC", price: 290000, code: "PG1200" },
                { name: "PUBG - 1800 UC", price: 435000, code: "PG1800" },
                { name: "PUBG - 3000 UC", price: 725000, code: "PG3000" },
                { name: "PUBG - 6000 UC", price: 1450000, code: "PG6000" },
                { name: "PUBG - Royale Pass", price: 145000, code: "PGRP" },
                
                // Genshin Impact
                { name: "Genshin - 60 Genesis Crystals", price: 16000, code: "GI60" },
                { name: "Genshin - 300+30 Genesis Crystals", price: 80000, code: "GI300" },
                { name: "Genshin - 980+110 Genesis Crystals", price: 250000, code: "GI980" },
                { name: "Genshin - 1980+260 Genesis Crystals", price: 500000, code: "GI1980" },
                { name: "Genshin - 3280+600 Genesis Crystals", price: 825000, code: "GI3280" },
                { name: "Genshin - 6480+1600 Genesis Crystals", price: 1650000, code: "GI6480" },
                { name: "Genshin - Blessing of the Welkin Moon", price: 80000, code: "GIBWM" },
                
                // Valorant
                { name: "Valorant - 420 Points", price: 50000, code: "VL420" },
                { name: "Valorant - 700 Points", price: 80000, code: "VL700" },
                { name: "Valorant - 1375 Points", price: 150000, code: "VL1375" },
                { name: "Valorant - 2400 Points", price: 250000, code: "VL2400" },
                { name: "Valorant - 4000 Points", price: 400000, code: "VL4000" },
                { name: "Valorant - 8150 Points", price: 800000, code: "VL8150" },
                
                // Call of Duty Mobile
                { name: "CODM - 53 CP", price: 10000, code: "COD53" },
                { name: "CODM - 106 CP", price: 20000, code: "COD106" },
                { name: "CODM - 264 CP", price: 50000, code: "COD264" },
                { name: "CODM - 528 CP", price: 100000, code: "COD528" },
                { name: "CODM - 1056 CP", price: 200000, code: "COD1056" },
                { name: "CODM - 1584 CP", price: 300000, code: "COD1584" },
                { name: "CODM - 2640 CP", price: 500000, code: "COD2640" },
                
                // Clash of Clans
                { name: "COC - 80 Gems", price: 15000, code: "COC80" },
                { name: "COC - 500 Gems", price: 75000, code: "COC500" },
                { name: "COC - 1200 Gems", price: 150000, code: "COC1200" },
                { name: "COC - 2500 Gems", price: 300000, code: "COC2500" },
                { name: "COC - 6500 Gems", price: 750000, code: "COC6500" },
                { name: "COC - 14000 Gems", price: 1500000, code: "COC14000" },
                
                // League of Legends: Wild Rift
                { name: "Wild Rift - 105 Wild Cores", price: 15000, code: "WR105" },
                { name: "Wild Rift - 400 Wild Cores", price: 55000, code: "WR400" },
                { name: "Wild Rift - 825 Wild Cores", price: 110000, code: "WR825" },
                { name: "Wild Rift - 1650 Wild Cores", price: 220000, code: "WR1650" },
                { name: "Wild Rift - 3300 Wild Cores", price: 440000, code: "WR3300" },
                { name: "Wild Rift - 5800 Wild Cores", price: 770000, code: "WR5800" },
                
                // Arena of Valor
                { name: "AOV - 40 Vouchers", price: 10000, code: "AOV40" },
                { name: "AOV - 90 Vouchers", price: 20000, code: "AOV90" },
                { name: "AOV - 230 Vouchers", price: 50000, code: "AOV230" },
                { name: "AOV - 470 Vouchers", price: 100000, code: "AOV470" },
                { name: "AOV - 950 Vouchers", price: 200000, code: "AOV950" },
                { name: "AOV - 1430 Vouchers", price: 300000, code: "AOV1430" },
                
                // Higgs Domino Island
                { name: "Higgs Domino - 30M Koin", price: 8000, code: "HD30M" },
                { name: "Higgs Domino - 60M Koin", price: 16000, code: "HD60M" },
                { name: "Higgs Domino - 100M Koin", price: 24000, code: "HD100M" },
                { name: "Higgs Domino - 200M Koin", price: 48000, code: "HD200M" },
                { name: "Higgs Domino - 400M Koin", price: 95000, code: "HD400M" },
                { name: "Higgs Domino - 1B Koin", price: 240000, code: "HD1B" },
                { name: "Higgs Domino - 2B Koin", price: 470000, code: "HD2B" }
            ]
        },
    ],

    // Messages
    messages: {
        welcome: "Halo! Terima kasih telah menggunakan bot kami. Ketik *!menu* untuk melihat daftar perintah.",
        contactOwner: "Silahkan hubungi pemilik bot untuk informasi lebih lanjut.",
        depositInfo: "Untuk melakukan deposit, silahkan hubungi owner bot.",
        notOwner: "Maaf, perintah ini hanya dapat diakses oleh pemilik bot.",
    },
    
    // Command descriptions for help/menu
    commandDescriptions: {
        menu: "Menampilkan daftar perintah yang tersedia",
        catalog: "Menampilkan katalog produk digital",
        deposit: "Informasi cara melakukan deposit",
        owner: "Menampilkan informasi pemilik bot",
        tiktok: "Download video TikTok (khusus owner)",
        rvo: "Reply pesan sekali lihat (khusus owner)",
    },
    
    // Bot appearance settings
    appearance: {
        headerFont: "Standard", // Figlet font for headers
        primaryColor: "#25D366", // Primary color (WhatsApp green)
        secondaryColor: "#128C7E", // Secondary color
        errorColor: "#FF0000", // Error message color
        successColor: "#32CD32", // Success message color
    },
    
    // API Endpoints
    apis: {
        tiktok: "https://api.ryzendesu.vip/api/downloader/ttdl",
    },
    
    // Bot runtime options
    options: {
        autoRead: true, // Auto read incoming messages
        autoReply: true, // Auto reply to non-command messages in private chat
        logIncomingMessages: true, // Log incoming messages to console
        logOutgoingMessages: false, // Log outgoing messages to console
        groupsSupport: false, // Whether to enable commands in groups
    }
};

export default config;