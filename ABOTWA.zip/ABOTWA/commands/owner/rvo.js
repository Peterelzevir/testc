// commands/owner/rvo.js - Reply View Once command
const { isOwner } = require('../../lib/database.js');
const config = require('../../config.js');

const handleRVO = async (sock, msg, args) => {
    try {
        // Get sender ID
        const sender = msg.key.remoteJid;
        
        // Check if user is owner
        if (!isOwner(sender)) {
            await sock.sendMessage(
                sender,
                { text: config.messages.notOwner },
                { quoted: msg }
            );
            return;
        }
        
        // Check if the message is a reply to a view once message
        if (!msg.message || !msg.message.extendedTextMessage || !msg.message.extendedTextMessage.contextInfo || !msg.message.extendedTextMessage.contextInfo.quotedMessage) {
            await sock.sendMessage(
                sender,
                { text: '❌ Mohon reply pesan sekali lihat (view once) yang ingin dilihat!' },
                { quoted: msg }
            );
            return;
        }
        
        const quotedMsg = msg.message.extendedTextMessage.contextInfo.quotedMessage;
        
        // Check if the quoted message is a view once message
        if (!quotedMsg.viewOnceMessage) {
            await sock.sendMessage(
                sender,
                { text: '❌ Pesan yang direply bukan pesan sekali lihat (view once)!' },
                { quoted: msg }
            );
            return;
        }
        
        // Extract the view once content
        const viewOnceContent = quotedMsg.viewOnceMessage.message;
        
        // Check content type and forward accordingly
        if (viewOnceContent.imageMessage) {
            // It's a view once image
            const image = await sock.downloadMediaMessage({
                message: {
                    imageMessage: viewOnceContent.imageMessage
                }
            });
            
            // Send the image back to the user
            await sock.sendMessage(
                sender,
                { 
                    image: image,
                    caption: viewOnceContent.imageMessage.caption || '📸 View Once Image'
                },
                { quoted: msg }
            );
        } else if (viewOnceContent.videoMessage) {
            // It's a view once video
            const video = await sock.downloadMediaMessage({
                message: {
                    videoMessage: viewOnceContent.videoMessage
                }
            });
            
            // Send the video back to the user
            await sock.sendMessage(
                sender,
                { 
                    video: video,
                    caption: viewOnceContent.videoMessage.caption || '🎬 View Once Video'
                },
                { quoted: msg }
            );
        } else if (viewOnceContent.audioMessage) {
            // It's a view once audio
            const audio = await sock.downloadMediaMessage({
                message: {
                    audioMessage: viewOnceContent.audioMessage
                }
            });
            
            // Send the audio back to the user
            await sock.sendMessage(
                sender,
                { audio: audio },
                { quoted: msg }
            );
        } else {
            // Unsupported view once content
            await sock.sendMessage(
                sender,
                { text: '❌ Jenis pesan sekali lihat tidak didukung!' },
                { quoted: msg }
            );
        }
    } catch (error) {
        console.error('Error handling RVO command:', error);
        
        // Send error message
        await sock.sendMessage(
            msg.key.remoteJid,
            { text: '❌ Terjadi kesalahan saat memproses pesan sekali lihat. Silakan coba lagi nanti.' },
            { quoted: msg }
        );
    }
};

module.exports = { handleRVO };