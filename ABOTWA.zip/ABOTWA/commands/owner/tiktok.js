// commands/owner/tiktok.js - TikTok downloader command

import { downloadTikTok } from '../../lib/downloader.js';
import { isOwner } from '../../lib/database.js';
import config from '../../config.js';

const handleTikTok = async (sock, msg, args) => {
    try {
        // Get sender ID
        const sender = msg.key.remoteJid;
        
        // Check if user is owner
        if (!isOwner(sender)) {
            await sock.sendMessage(
                sender,
                { text: config.messages.notOwner },
                { quoted: msg }
            );
            return;
        }
        
        // Check if URL is provided
        if (args.length === 0) {
            await sock.sendMessage(
                sender,
                { text: '❌ Mohon berikan URL TikTok!' },
                { quoted: msg }
            );
            return;
        }
        
        // Get TikTok URL
        const tiktokUrl = args[0];
        
        // Send processing message
        await sock.sendMessage(
            sender,
            { text: '⏳ Sedang memproses video TikTok...' },
            { quoted: msg }
        );
        
        // Download TikTok video
        const result = await downloadTikTok(tiktokUrl);
        
        if (result.success) {
            // Send video
            await sock.sendMessage(
                sender,
                { 
                    video: { url: result.videoUrl },
                    caption: `*TikTok Downloader*\n\n${result.caption}\n\n👤 Author: ${result.authorName}\n❤️ Likes: ${result.likes}\n💬 Comments: ${result.comments}\n🔄 Shares: ${result.shares}`
                },
                { quoted: msg }
            );
        } else {
            // Send error message
            await sock.sendMessage(
                sender,
                { text: `❌ ${result.message}` },
                { quoted: msg }
            );
        }
    } catch (error) {
        console.error('Error handling TikTok command:', error);
        
        // Send error message
        await sock.sendMessage(
            msg.key.remoteJid,
            { text: '❌ Terjadi kesalahan saat mengunduh video TikTok. Silakan coba lagi nanti.' },
            { quoted: msg }
        );
    }
};

export { handleTikTok };