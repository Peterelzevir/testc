// commands/all/catalog.js - Catalog command

import { createCatalog } from '../../lib/formatter.js';
import config from '../../config.js';

const handleCatalog = async (sock, msg, args) => {
    try {
        // Check if a specific category is requested
        const category = args.length > 0 ? args.join(' ') : null;
        
        // Generate catalog text
        const catalogText = createCatalog(category);
        
        // Send catalog message
        await sock.sendMessage(
            msg.key.remoteJid,
            { text: catalogText },
            { quoted: msg }
        );
        
        // Send contact of the owner
        await sock.sendContact(
            msg.key.remoteJid,
            config.owner.number,
            config.owner.name
        );
        
    } catch (error) {
        console.error('Error handling catalog command:', error);
        
        // Send error message
        await sock.sendMessage(
            msg.key.remoteJid,
            { text: '❌ Terjadi kesalahan saat memuat katalog. Silakan coba lagi nanti.' },
            { quoted: msg }
        );
    }
};

export { handleCatalog };