// index.js - Main bot file
// Based on working test-connection.js approach
// by @hiyaok

const { default: makeWASocket, useMultiFileAuthState, DisconnectReason } = require('@whiskeysockets/baileys');
const pino = require('pino');
const { Boom } = require('@hapi/boom');
const fs = require('fs-extra');
const path = require('path');
const figlet = require('figlet');
const chalk = require('chalk');
const axios = require('axios');

// Ensure crypto is available globally for Baileys
global.crypto = require('crypto');

// Import config
const config = require('./config');

// Create fancy text banner
function createFancyText(text) {
    try {
        return figlet.textSync(text, {
            font: config.appearance.headerFont || 'Standard',
            horizontalLayout: 'default',
            verticalLayout: 'default',
            width: 80,
            whitespaceBreak: true
        });
    } catch (error) {
        console.error('Error creating fancy text:', error);
        return text;
    }
}

// Format price to IDR
function formatPrice(price) {
    return 'Rp ' + price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

// Create formatted message
function formatMessage(title, content, footer = null) {
    let message = `╭───「 *${title}* 」───\n│\n`;
    
    // Split content by lines and add prefix
    const contentLines = content.split('\n');
    contentLines.forEach(line => {
        message += `│ ${line}\n`;
    });
    
    message += `│\n`;
    
    if (footer) {
        message += `╰───「 _${footer}_ 」───`;
    } else {
        message += `╰─────────────────`;
    }
    
    return message;
}

// Check if a user is owner
function isOwner(userId) {
    // Remove any non-numeric characters and compare
    const cleanUserId = userId.replace(/\D/g, '');
    const cleanOwner = config.owner.number.replace(/\D/g, '');
    
    return cleanUserId.endsWith(cleanOwner);
}

// Create fancy menu
function createMenu(isUserOwner = false) {
    const botName = config.bot.name;
    const botVersion = config.bot.version;
    const prefix = config.bot.prefix;
    
    let menuText = `╔═══════════════════════════╗
║ ${centerText(botName, 27)} ║
╠═══════════════════════════╣
║ ${centerText(`v${botVersion}`, 27)} ║
╚═══════════════════════════╝\n\n`;

    menuText += `📖 *𝔻𝔸𝔽𝕋𝔸ℝ 𝕄𝔼ℕ𝕌*\n\n`;
    
    // Public commands
    menuText += `⭐ *𝕄𝔼ℕ𝕌 𝕌𝕄𝕌𝕄*\n`;
    menuText += `├ ${prefix}menu - Menampilkan daftar perintah\n`;
    menuText += `├ ${prefix}catalog - Menampilkan katalog produk\n`;
    menuText += `├ ${prefix}deposit - Info cara deposit\n`;
    menuText += `└ ${prefix}owner - Menampilkan info owner\n\n`;
    
    // Owner commands (shown only to owner)
    if (isUserOwner) {
        menuText += `👑 *𝕄𝔼ℕ𝕌 𝕆𝕎ℕ𝔼ℝ*\n`;
        menuText += `├ ${prefix}tiktok [url] - Download video TikTok\n`;
        menuText += `└ ${prefix}rvo - Reply pesan sekali lihat\n\n`;
    }
    
    menuText += `📝 *𝕀ℕ𝔽𝕆 𝔹𝕆𝕋*\n`;
    menuText += `Bot ini dibuat untuk memudahkan Anda\n`;
    menuText += `dalam bertransaksi digital.\n\n`;
    menuText += `👤 *𝕆𝕎ℕ𝔼ℝ 𝔹𝕆𝕋*\n`;
    menuText += `${config.owner.name} (${config.owner.numberWithPlus})`;
    
    return menuText;
}

// Center text in a fixed width space
function centerText(text, width) {
    if (text.length >= width) {
        return text;
    }
    
    const leftPadding = Math.floor((width - text.length) / 2);
    const rightPadding = width - text.length - leftPadding;
    
    return ' '.repeat(leftPadding) + text + ' '.repeat(rightPadding);
}

// Create catalog text
function createCatalog(category = null) {
    try {
        const catalogHeader = `╔═══════════════════════════╗
║ ${centerText(config.catalog.title, 27)} ║
╚═══════════════════════════╝`;

        let catalogText = catalogHeader + "\n\n";
        
        // Filter categories if specified
        const categories = category 
            ? config.catalogItems.filter(cat => cat.category.toLowerCase() === category.toLowerCase()) 
            : config.catalogItems;
        
        // Generate catalog for each category
        categories.forEach(cat => {
            catalogText += `┏━━━━━━━━━━[ *${cat.category}* ]━━━━━━━━━━┓\n\n`;
            
            cat.items.forEach((item, index) => {
                catalogText += `${index + 1}. *${item.name}*\n`;
                catalogText += `   ├ Kode: ${item.code}\n`;
                catalogText += `   └ Harga: ${formatPrice(item.price)}\n\n`;
            });
            
            catalogText += `┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n`;
        });
        
        catalogText += `✅ *CARA ORDER:*\n`;
        catalogText += `Silahkan hubungi Owner untuk pemesanan\n`;
        catalogText += `👤 Owner: wa.me/${config.owner.number}\n\n`;
        catalogText += `📝 *NOTE:*\n`;
        catalogText += `Harga dapat berubah sewaktu-waktu\n`;
        catalogText += `Pembayaran hanya melalui metode yang disediakan Owner`;
        
        return catalogText;
    } catch (error) {
        console.error('Error creating catalog:', error);
        return 'Error creating catalog. Please try again later.';
    }
}

// TikTok downloader function
async function downloadTikTok(url) {
    try {
        // Validate URL
        if (!url || !url.includes('tiktok.com')) {
            return {
                success: false,
                message: 'URL TikTok tidak valid!'
            };
        }
        
        // Call TikTok API
        const apiUrl = `https://api.ryzendesu.vip/api/downloader/ttdl?url=${encodeURIComponent(url)}`;
        
        const response = await axios.get(apiUrl);
        const data = response.data;
        
        // Check if API response is successful
        if (data && data.status && data.data && data.data.hdplay) {
            return {
                success: true,
                videoUrl: data.data.hdplay,
                caption: data.data.description || 'TikTok Video',
                authorName: data.data.author?.name || 'Unknown Author',
                authorAvatar: data.data.author?.avatar || '',
                music: data.data.music || '',
                likes: data.data.stats?.likeCount || 0,
                shares: data.data.stats?.shareCount || 0,
                comments: data.data.stats?.commentCount || 0
            };
        } else {
            return {
                success: false,
                message: 'Gagal mendapatkan video TikTok!'
            };
        }
    } catch (error) {
        console.error('Error downloading TikTok:', error);
        return {
            success: false,
            message: 'Error: ' + (error.message || 'Gagal mengunduh video TikTok!')
        };
    }
}

// Initialize database
function initDatabase() {
    try {
        const dbPath = config.database.path || './database.json';
        
        // Create database file if it doesn't exist
        if (!fs.existsSync(dbPath)) {
            const defaultData = {
                users: [],
                transactions: [],
                settings: {
                    lastUpdated: new Date().toISOString()
                }
            };
            
            fs.writeJsonSync(dbPath, defaultData, { spaces: 2 });
            console.log('Database initialized successfully!');
        }
        
        return true;
    } catch (error) {
        console.error('Error initializing database:', error);
        return false;
    }
}

// Register user in database
async function registerUser(userId, name) {
    try {
        const dbPath = config.database.path || './database.json';
        const db = fs.readJsonSync(dbPath);
        
        // Check if user already exists
        const existingUser = db.users.find(user => user.id === userId);
        
        if (!existingUser) {
            db.users.push({
                id: userId,
                name: name,
                registeredAt: new Date().toISOString(),
                isActive: true
            });
            
            fs.writeJsonSync(dbPath, db, { spaces: 2 });
            return true;
        }
        
        return false;
    } catch (error) {
        console.error('Error registering user:', error);
        return false;
    }
}

// Print fancy banner
console.log('\n' + chalk.cyan(createFancyText(config.bot.name)) + '\n');
console.log(chalk.yellow(`🤖 ${config.bot.name} v${config.bot.version}`));
console.log(chalk.yellow(`👤 Owner: ${config.owner.name} (${config.owner.numberWithPlus})\n`));

// Create authentication folder if it doesn't exist
const AUTH_FOLDER = './baileys_auth';
if (!fs.existsSync(AUTH_FOLDER)) {
    fs.mkdirSync(AUTH_FOLDER, { recursive: true });
}

// Main function to connect to WhatsApp
async function connectToWhatsApp() {
    // Initialize database
    initDatabase();
    
    // Check if using pairing mode
    const usePairingCode = process.argv.includes('--pairing');
    const phoneNumber = usePairingCode ? process.argv[process.argv.indexOf('--pairing') + 1] : undefined;
    
    // Log connection method
    if (usePairingCode && phoneNumber) {
        console.log(chalk.blue('Mode koneksi:'), chalk.yellow('Pairing Code'));
        console.log(chalk.blue('Nomor telepon:'), chalk.yellow(phoneNumber));
    } else {
        console.log(chalk.blue('Mode koneksi:'), chalk.yellow('QR Code'));
    }
    
    // Get authentication state
    const { state, saveCreds } = await useMultiFileAuthState(AUTH_FOLDER);
    
    // Create WhatsApp socket connection
    const sock = makeWASocket({
        printQRInTerminal: !usePairingCode, // Don't print QR if using pairing
        auth: state,
        logger: pino({ level: 'silent' }),
        browser: ['Chrome (Linux)', '', ''],
        ...(usePairingCode && phoneNumber ? {
            pairingCode: true,
            phoneNumber: phoneNumber,
        } : {})
    });
    
    // Handle credentials update
    sock.ev.on('creds.update', saveCreds);
    
    // Handle connection updates
    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect, qr, pairingCode } = update;
        
        // Display pairing code if using pairing mode
        if (usePairingCode && pairingCode) {
            console.log(chalk.blue('\nKode Pairing:'), chalk.green(pairingCode));
            console.log(chalk.yellow('\nMasukkan kode di atas di WhatsApp Anda > Linked Devices > Link a Device\n'));
        }
        
        if (connection === 'close') {
            const shouldReconnect = (lastDisconnect.error instanceof Boom) 
                ? lastDisconnect.error.output.statusCode !== DisconnectReason.loggedOut 
                : true;
                
            console.log(chalk.red('❌ Connection closed due to '), lastDisconnect.error, ', reconnecting: ', shouldReconnect);
            
            if (shouldReconnect) {
                connectToWhatsApp();
            } else {
                console.log(chalk.red('💤 Connection terminated. Please restart the program.'));
            }
        } else if (connection === 'open') {
            console.log(chalk.green('✅ WhatsApp bot connected!'));
            console.log(chalk.green('🤖 Bot is now ready to use!'));
            
            // Display connected account info
            try {
                const info = sock.user;
                console.log(chalk.blue('\nAccount Information:'));
                console.log(chalk.blue('Name:'), chalk.yellow(info.name));
                console.log(chalk.blue('Number:'), chalk.yellow(info.id.split(':')[0]));
                console.log(chalk.blue('Platform:'), chalk.yellow(info.platform || 'Unknown'));
            } catch (error) {
                console.log(chalk.red('Could not retrieve device information:', error));
            }
        }
    });
    
    // Handle incoming messages
    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;
        
        // Process each incoming message
        for (const msg of messages) {
            try {
                if (!msg.message) continue;
                
                // Check if message is from user (not from bot)
                if (msg.key && msg.key.fromMe === false) {
                    // Get basic message info
                    const sender = msg.key.remoteJid;
                    const isGroup = sender.endsWith('@g.us');
                    const senderName = msg.pushName || 'User';
                    
                    // Register user in database
                    await registerUser(sender, senderName);
                    
                    // Extract message text
                    const messageTypes = ['conversation', 'extendedTextMessage', 'imageMessage', 'videoMessage'];
                    let messageText = '';
                    
                    for (const type of messageTypes) {
                        if (msg.message[type]) {
                            if (type === 'conversation') {
                                messageText = msg.message.conversation;
                            } else if (type === 'extendedTextMessage') {
                                messageText = msg.message.extendedTextMessage.text;
                            } else if (type === 'imageMessage' || type === 'videoMessage') {
                                messageText = msg.message[type].caption || '';
                            }
                            break;
                        }
                    }
                    
                    // Show incoming message in console (for debugging)
                    console.log(chalk.yellow(`[${new Date().toLocaleTimeString()}] ${senderName} (${sender.split('@')[0]}): ${messageText}`));
                    
                    // Process commands
                    if (messageText.startsWith(config.bot.prefix)) {
                        // Split command and arguments
                        const [command, ...args] = messageText.slice(config.bot.prefix.length).trim().split(' ');
                        
                        // Process different commands
                        switch (command.toLowerCase()) {
                            case 'menu':
                                // Send menu
                                const menuText = createMenu(isOwner(sender));
                                await sock.sendMessage(sender, { text: menuText }, { quoted: msg });
                                break;
                                
                            case 'catalog':
                                // Handle catalog command
                                const category = args.length > 0 ? args.join(' ') : null;
                                const catalogText = createCatalog(category);
                                
                                await sock.sendMessage(sender, { text: catalogText }, { quoted: msg });
                                
                                // Send owner contact
                                await sock.sendContact(
                                    sender,
                                    config.owner.number,
                                    config.owner.name
                                );
                                break;
                                
                            case 'deposit':
                                // Send deposit information
                                await sock.sendMessage(
                                    sender,
                                    { text: formatMessage('𝔻𝔼ℙ𝕆𝕊𝕀𝕋 𝕀ℕ𝔽𝕆', config.messages.depositInfo, config.bot.name) },
                                    { quoted: msg }
                                );
                                
                                // Send owner contact
                                await sock.sendContact(
                                    sender,
                                    config.owner.number,
                                    config.owner.name
                                );
                                break;
                                
                            case 'owner':
                                // Send owner contact
                                await sock.sendMessage(
                                    sender,
                                    { text: '👤 *𝕆𝕎ℕ𝔼ℝ 𝔹𝕆𝕋*\nBerikut adalah kontak owner bot:' },
                                    { quoted: msg }
                                );
                                
                                await sock.sendContact(
                                    sender,
                                    config.owner.number,
                                    config.owner.name
                                );
                                break;
                                
                            case 'tiktok':
                                // Handle TikTok download command (owner only)
                                if (!isOwner(sender)) {
                                    await sock.sendMessage(
                                        sender,
                                        { text: config.messages.notOwner },
                                        { quoted: msg }
                                    );
                                    return;
                                }
                                
                                if (args.length === 0) {
                                    await sock.sendMessage(
                                        sender,
                                        { text: '❌ Mohon berikan URL TikTok!' },
                                        { quoted: msg }
                                    );
                                    return;
                                }
                                
                                // Get TikTok URL
                                const tiktokUrl = args[0];
                                
                                // Send processing message
                                await sock.sendMessage(
                                    sender,
                                    { text: '⏳ Sedang memproses video TikTok...' },
                                    { quoted: msg }
                                );
                                
                                // Download TikTok video
                                const result = await downloadTikTok(tiktokUrl);
                                
                                if (result.success) {
                                    // Send video
                                    await sock.sendMessage(
                                        sender,
                                        { 
                                            video: { url: result.videoUrl },
                                            caption: `*TikTok Downloader*\n\n${result.caption}\n\n👤 Author: ${result.authorName}\n❤️ Likes: ${result.likes}\n💬 Comments: ${result.comments}\n🔄 Shares: ${result.shares}`
                                        },
                                        { quoted: msg }
                                    );
                                } else {
                                    // Send error message
                                    await sock.sendMessage(
                                        sender,
                                        { text: `❌ ${result.message}` },
                                        { quoted: msg }
                                    );
                                }
                                break;
                                
                            case 'rvo':
                                // Handle Reply View Once command (owner only)
                                if (!isOwner(sender)) {
                                    await sock.sendMessage(
                                        sender,
                                        { text: config.messages.notOwner },
                                        { quoted: msg }
                                    );
                                    return;
                                }
                                
                                // Check if the message is a reply to a view once message
                                if (!msg.message || !msg.message.extendedTextMessage || !msg.message.extendedTextMessage.contextInfo || !msg.message.extendedTextMessage.contextInfo.quotedMessage) {
                                    await sock.sendMessage(
                                        sender,
                                        { text: '❌ Mohon reply pesan sekali lihat (view once) yang ingin dilihat!' },
                                        { quoted: msg }
                                    );
                                    return;
                                }
                                
                                const quotedMsg = msg.message.extendedTextMessage.contextInfo.quotedMessage;
                                
                                // Check if the quoted message is a view once message
                                if (!quotedMsg.viewOnceMessage) {
                                    await sock.sendMessage(
                                        sender,
                                        { text: '❌ Pesan yang direply bukan pesan sekali lihat (view once)!' },
                                        { quoted: msg }
                                    );
                                    return;
                                }
                                
                                // Extract the view once content
                                const viewOnceContent = quotedMsg.viewOnceMessage.message;
                                
                                // Check content type and forward accordingly
                                if (viewOnceContent.imageMessage) {
                                    // It's a view once image
                                    const image = await sock.downloadMediaMessage({
                                        message: {
                                            imageMessage: viewOnceContent.imageMessage
                                        }
                                    });
                                    
                                    // Send the image back to the user
                                    await sock.sendMessage(
                                        sender,
                                        { 
                                            image: image,
                                            caption: viewOnceContent.imageMessage.caption || '📸 View Once Image'
                                        },
                                        { quoted: msg }
                                    );
                                } else if (viewOnceContent.videoMessage) {
                                    // It's a view once video
                                    const video = await sock.downloadMediaMessage({
                                        message: {
                                            videoMessage: viewOnceContent.videoMessage
                                        }
                                    });
                                    
                                    // Send the video back to the user
                                    await sock.sendMessage(
                                        sender,
                                        { 
                                            video: video,
                                            caption: viewOnceContent.videoMessage.caption || '🎬 View Once Video'
                                        },
                                        { quoted: msg }
                                    );
                                } else if (viewOnceContent.audioMessage) {
                                    // It's a view once audio
                                    const audio = await sock.downloadMediaMessage({
                                        message: {
                                            audioMessage: viewOnceContent.audioMessage
                                        }
                                    });
                                    
                                    // Send the audio back to the user
                                    await sock.sendMessage(
                                        sender,
                                        { audio: audio },
                                        { quoted: msg }
                                    );
                                } else {
                                    // Unsupported view once content
                                    await sock.sendMessage(
                                        sender,
                                        { text: '❌ Jenis pesan sekali lihat tidak didukung!' },
                                        { quoted: msg }
                                    );
                                }
                                break;
                                
                            default:
                                // Unknown command
                                if (isGroup) return; // Don't respond to unknown commands in groups
                                
                                await sock.sendMessage(
                                    sender,
                                    { text: `❓ Perintah tidak dikenal. Ketik *${config.bot.prefix}menu* untuk melihat daftar perintah.` },
                                    { quoted: msg }
                                );
                                break;
                        }
                    } else if (!isGroup && config.options.autoReply) {
                        // Auto-respond to non-command messages in private chat
                        // Send welcome message for first-time users
                        await sock.sendMessage(
                            sender,
                            { text: config.messages.welcome },
                            { quoted: msg }
                        );
                    }
                }
            } catch (error) {
                console.error('Error processing message:', error);
            }
        }
    });
}

// Start the bot
connectToWhatsApp().catch(err => console.log('Error in main function:', err));

console.log(chalk.yellow('\nWaiting for connection...'));
console.log(chalk.yellow('To use pairing code: node index.js --pairing 628xxxxxxxx'));