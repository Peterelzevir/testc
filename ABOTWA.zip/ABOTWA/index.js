// index.js - Main entry point

// Import required packages
import { default as makeWASocket, DisconnectReason, useMultiFileAuthState, fetchLatestBaileysVersion } from '@whiskeysockets/baileys';
import P from 'pino';
import { Boom } from '@hapi/boom';
import fs from 'fs-extra';
import path from 'path';
import figlet from 'figlet';
import chalk from 'chalk';

// Import local modules
import config from './config.js';
import { initDatabase, isOwner, registerUser } from './lib/database.js';
import { createFancyText, formatMessage, createMenu } from './lib/formatter.js';
import { handleCatalog } from './commands/all/catalog.js';
import { handleTikTok } from './commands/owner/tiktok.js';
import { handleRVO } from './commands/owner/rvo.js';

// Print fancy banner
console.log('\n' + chalk.cyan(createFancyText(config.bot.name)) + '\n');
console.log(chalk.yellow(`🤖 ${config.bot.name} v${config.bot.version}`));
console.log(chalk.yellow(`👤 Owner: ${config.owner.name} (${config.owner.numberWithPlus})\n`));

// Create baileys auth state directory
const AUTH_FOLDER = './baileys_auth';
if (!fs.existsSync(AUTH_FOLDER)) {
    fs.mkdirSync(AUTH_FOLDER, { recursive: true });
}

// Connect function to start WhatsApp bot
async function connectToWhatsApp() {
    // Initialize database
    await initDatabase();
    
    // Get authentication state
    const { state, saveCreds } = await useMultiFileAuthState(AUTH_FOLDER);
    
    // Fetch latest baileys version
    const { version } = await fetchLatestBaileysVersion();
    console.log(chalk.blue(`Using WA Web version: ${version.join('.')}`));

    // Create WhatsApp socket connection
    const sock = makeWASocket({
        version,
        logger: P({ level: 'silent' }),
        printQRInTerminal: true,
        auth: state,
        browser: ['Chrome (Linux)', '', '']
    });

    // Handle credentials update
    sock.ev.on('creds.update', saveCreds);

    // Handle connection updates
    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        
        if (connection === 'close') {
            const shouldReconnect = (lastDisconnect.error instanceof Boom) 
                ? lastDisconnect.error.output.statusCode !== DisconnectReason.loggedOut 
                : true;
                
            console.log(chalk.red('❌ Connection closed due to '), lastDisconnect.error, ', reconnecting: ', shouldReconnect);
            
            if (shouldReconnect) {
                connectToWhatsApp();
            }
        } else if (connection === 'open') {
            console.log(chalk.green('✅ WhatsApp bot connected!'));
            console.log(chalk.green('🤖 Bot is now ready to use!'));
        }
    });

    // Handle incoming messages
    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;
        
        // Process each incoming message
        for (const msg of messages) {
            try {
                if (!msg.message) continue;
                
                // Check if message is from user (not from bot)
                if (msg.key && msg.key.fromMe === false) {
                    // Get basic message info
                    const sender = msg.key.remoteJid;
                    const isGroup = sender.endsWith('@g.us');
                    const senderName = msg.pushName || 'User';
                    
                    // Register user in database
                    await registerUser(sender, senderName);
                    
                    // Extract message text
                    const messageTypes = ['conversation', 'extendedTextMessage', 'imageMessage', 'videoMessage'];
                    let messageText = '';
                    
                    for (const type of messageTypes) {
                        if (msg.message[type]) {
                            if (type === 'conversation') {
                                messageText = msg.message.conversation;
                            } else if (type === 'extendedTextMessage') {
                                messageText = msg.message.extendedTextMessage.text;
                            } else if (type === 'imageMessage' || type === 'videoMessage') {
                                messageText = msg.message[type].caption || '';
                            }
                            break;
                        }
                    }
                    
                    // Show incoming message in console (for debugging)
                    console.log(chalk.yellow(`[${new Date().toLocaleTimeString()}] ${senderName} (${sender.split('@')[0]}): ${messageText}`));
                    
                    // Process commands
                    if (messageText.startsWith(config.bot.prefix)) {
                        // Split command and arguments
                        const [command, ...args] = messageText.slice(config.bot.prefix.length).trim().split(' ');
                        
                        // Process different commands
                        switch (command.toLowerCase()) {
                            case 'menu':
                                // Send menu
                                const menuText = createMenu(isOwner(sender));
                                await sock.sendMessage(sender, { text: menuText }, { quoted: msg });
                                break;
                                
                            case 'catalog':
                                // Handle catalog command
                                await handleCatalog(sock, msg, args);
                                break;
                                
                            case 'deposit':
                                // Send deposit information
                                await sock.sendMessage(
                                    sender,
                                    { text: formatMessage('𝔻𝔼ℙ𝕆𝕊𝕀𝕋 𝕀ℕ𝔽𝕆', config.messages.depositInfo, config.bot.name) },
                                    { quoted: msg }
                                );
                                
                                // Send owner contact
                                await sock.sendContact(
                                    sender,
                                    config.owner.number,
                                    config.owner.name
                                );
                                break;
                                
                            case 'owner':
                                // Send owner contact
                                await sock.sendMessage(
                                    sender,
                                    { text: '👤 *𝕆𝕎ℕ𝔼ℝ 𝔹𝕆𝕋*\nBerikut adalah kontak owner bot:' },
                                    { quoted: msg }
                                );
                                
                                await sock.sendContact(
                                    sender,
                                    config.owner.number,
                                    config.owner.name
                                );
                                break;
                                
                            case 'tiktok':
                                // Handle TikTok download command
                                await handleTikTok(sock, msg, args);
                                break;
                                
                            case 'rvo':
                                // Handle Reply View Once command
                                await handleRVO(sock, msg, args);
                                break;
                                
                            default:
                                // Unknown command
                                if (isGroup) return; // Don't respond to unknown commands in groups
                                
                                await sock.sendMessage(
                                    sender,
                                    { text: `❓ Perintah tidak dikenal. Ketik *${config.bot.prefix}menu* untuk melihat daftar perintah.` },
                                    { quoted: msg }
                                );
                                break;
                        }
                    } else if (!isGroup) {
                        // Auto-respond to non-command messages in private chat
                        // Send welcome message for first-time users
                        await sock.sendMessage(
                            sender,
                            { text: config.messages.welcome },
                            { quoted: msg }
                        );
                    }
                }
            } catch (error) {
                console.error('Error processing message:', error);
            }
        }
    });
}

// Start the bot
connectToWhatsApp();