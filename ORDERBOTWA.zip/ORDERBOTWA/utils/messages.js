// utils/messages.js
const config = require('../config/config');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs');
const { promisify } = require('util');
const writeFileAsync = promisify(fs.writeFile);

// Function to add styling to messages
const styleMessage = (text, style = 'none') => {
  switch (style) {
    case 'title':
      // Title: Bold with dividers and emojis
      return `\n┏━━━━━『 ${text} 』━━━━━┓\n`;
    case 'subtitle':
      // Subtitle: Light dividers
      return `\n┌──『 ${text} 』──┐\n`;
    case 'section':
      // Section divider
      return `\n▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n➤ ${text}\n▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰\n`;
    case 'success':
      // Success message
      return `✅ ${text}`;
    case 'error':
      // Error message
      return `❌ ${text}`;
    case 'warning':
      // Warning message
      return `⚠️ ${text}`;
    case 'info':
      // Info message
      return `ℹ️ ${text}`;
    case 'list':
      // List item
      return `  ◦ ${text}`;
    case 'footer':
      // Footer style
      return `\n┗━━━『 ${text} 』━━━┛\n`;
    default:
      return text;
  }
};

// Helper function to download media from message
const downloadMedia = async (message) => {
  try {
    let buffer = Buffer.from([]);
    let mediaType;
    let mimetype;
    
    if (message.imageMessage) {
      const stream = await downloadContentFromMessage(message.imageMessage, 'image');
      mediaType = 'image';
      mimetype = message.imageMessage.mimetype;
      
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }
    } else if (message.videoMessage) {
      const stream = await downloadContentFromMessage(message.videoMessage, 'video');
      mediaType = 'video';
      mimetype = message.videoMessage.mimetype;
      
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }
    } else if (message.documentMessage) {
      const stream = await downloadContentFromMessage(message.documentMessage, 'document');
      mediaType = 'document';
      mimetype = message.documentMessage.mimetype;
      
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }
    } else {
      throw new Error('No media found in message');
    }
    
    return { buffer, mediaType, mimetype };
  } catch (error) {
    console.error('Error downloading media:', error);
    throw error;
  }
};

// Custom message utility object
const hiyaok = {
  // Send a text message
  sendpesan: async (sock, jid, text, options = {}) => {
    try {
      // Apply styling if requested
      const formattedText = options.style ? styleMessage(text, options.style) : text;
      
      // Send the message
      const sentMsg = await sock.sendMessage(jid, { text: formattedText });
      return sentMsg;
    } catch (error) {
      console.error('Error sending message:', error);
      return false;
    }
  },
  
  // Send an image
  sendGambar: async (sock, jid, imageBuffer, caption = '', options = {}) => {
    try {
      // Apply styling to caption if requested
      const formattedCaption = options.style ? styleMessage(caption, options.style) : caption;
      
      // Send image
      const sentMsg = await sock.sendMessage(jid, { 
        image: imageBuffer, 
        caption: formattedCaption,
        jpegThumbnail: options.thumbnail // Optional thumbnail
      });
      return sentMsg;
    } catch (error) {
      console.error('Error sending image:', error);
      return false;
    }
  },
  
  // Send a video
  sendVideo: async (sock, jid, videoBuffer, caption = '', options = {}) => {
    try {
      // Apply styling to caption if requested
      const formattedCaption = options.style ? styleMessage(caption, options.style) : caption;
      
      // Send video
      const sentMsg = await sock.sendMessage(jid, { 
        video: videoBuffer, 
        caption: formattedCaption,
        jpegThumbnail: options.thumbnail, // Optional thumbnail
        gifPlayback: options.gif || false
      });
      return sentMsg;
    } catch (error) {
      console.error('Error sending video:', error);
      return false;
    }
  },
  
  // Send a file/document
  sendFile: async (sock, jid, fileBuffer, fileName, caption = '', options = {}) => {
    try {
      // Apply styling to caption if requested
      const formattedCaption = options.style ? styleMessage(caption, options.style) : caption;
      
      // Send document
      const sentMsg = await sock.sendMessage(jid, { 
        document: fileBuffer, 
        mimetype: options.mimetype || 'application/octet-stream', 
        fileName: fileName,
        caption: formattedCaption
      });
      return sentMsg;
    } catch (error) {
      console.error('Error sending file:', error);
      return false;
    }
  },
  
  // Reply to a message
  reply: async (sock, jid, text, quoted, options = {}) => {
    try {
      // Apply styling if requested
      const formattedText = options.style ? styleMessage(text, options.style) : text;
      
      // Send reply
      const sentMsg = await sock.sendMessage(jid, { text: formattedText }, { quoted });
      return sentMsg;
    } catch (error) {
      console.error('Error sending reply:', error);
      return false;
    }
  },
  
  // Send a button message
  sendButton: async (sock, jid, text, buttons, options = {}) => {
    try {
      // Apply styling if requested
      const formattedText = options.style ? styleMessage(text, options.style) : text;
      
      // Format buttons
      const formattedButtons = buttons.map(btn => {
        return { buttonId: btn.id, buttonText: { displayText: btn.text }, type: 1 };
      });
      
      // Button message content
      const buttonMessage = {
        text: formattedText,
        buttons: formattedButtons,
        headerType: 1,
        viewOnce: options.viewOnce || false
      };
      
      // Add footer if provided
      if (options.footer) {
        buttonMessage.footer = options.footer;
      }
      
      // Send button message
      const sentMsg = await sock.sendMessage(jid, buttonMessage);
      return sentMsg;
    } catch (error) {
      console.error('Error sending button message:', error);
      return false;
    }
  },
  
  // Extract media from a message
  getMedia: async (message) => {
    try {
      return await downloadMedia(message);
    } catch (error) {
      console.error('Error getting media:', error);
      return null;
    }
  }
};

// Format product information
const formatProduct = (product) => {
  return `${styleMessage('DETAIL PRODUK', 'subtitle')}
🏷️ *Nama:* ${product.name}
💰 *Harga:* Rp${product.price.toLocaleString('id-ID')}
📦 *Stok:* ${product.stock}
${product.description ? `📝 *Deskripsi:* ${product.description}` : ''}
${styleMessage('', 'footer')}`;
};

// Format catalog list with pagination
const formatCatalog = (products, page = 1, perPage = 10) => {
  const start = (page - 1) * perPage;
  const end = start + perPage;
  const paginatedProducts = products.slice(start, end);
  
  let catalogText = styleMessage('KATALOG PRODUK', 'title');
  
  paginatedProducts.forEach((product, index) => {
    catalogText += `${styleMessage(`${start + index + 1}. ${product.name}`, 'list')}\n   💰 Rp${product.price.toLocaleString('id-ID')} | 📦 Stok: ${product.stock}\n`;
  });
  
  // Add pagination info
  catalogText += `\n📄 Halaman ${page} dari ${Math.ceil(products.length / perPage)}`;
  catalogText += `\n\nKetik !katalog ${page + 1} untuk halaman selanjutnya`;
  catalogText += styleMessage(`Total: ${products.length} Produk`, 'footer');
  
  return catalogText;
};

module.exports = {
  hiyaok,
  formatProduct,
  formatCatalog,
  styleMessage,
  downloadMedia
};