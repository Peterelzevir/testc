// utils/admin.js
const config = require('../config/config');

const isAdmin = (number) => {
  // Remove any non-numeric characters and ensure format is consistent
  const cleanNumber = number.replace(/[^\d]/g, '');
  return config.adminNumbers.some(admin => {
    const cleanAdmin = admin.replace(/[^\d]/g, '');
    return cleanNumber.includes(cleanAdmin);
  });
};

module.exports = { isAdmin };