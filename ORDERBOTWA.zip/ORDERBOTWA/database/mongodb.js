// database/mongodb.js
const mongoose = require('mongoose');
const config = require('../config/config');
const chalk = require('chalk');

const connectDB = async () => {
  try {
    await mongoose.connect(config.mongoURI);
    console.log(chalk.green('✅ MongoDB connected successfully'));
  } catch (error) {
    console.error(chalk.red('❌ MongoDB connection error:'), error.message);
    process.exit(1);
  }
};

// Product Schema
const productSchema = new mongoose.Schema({
  name: { type: String, required: true },
  price: { type: Number, required: true },
  stock: { type: Number, default: 0 },
  description: { type: String, default: '' },
  createdAt: { type: Date, default: Date.now }
});

// Settings Schema
const settingSchema = new mongoose.Schema({
  key: { type: String, required: true, unique: true },
  value: { type: mongoose.Schema.Types.Mixed, required: true }
});

// Media Schema for storing welcome/left media
const mediaSchema = new mongoose.Schema({
  type: { type: String, required: true }, // welcome or left
  mediaType: { type: String, required: true }, // image or video
  buffer: { type: Buffer, required: true },
  caption: { type: String, default: '' }
});

const Product = mongoose.model('Product', productSchema);
const Setting = mongoose.model('Setting', settingSchema);
const Media = mongoose.model('Media', mediaSchema);

module.exports = {
  connectDB,
  Product,
  Setting,
  Media
};