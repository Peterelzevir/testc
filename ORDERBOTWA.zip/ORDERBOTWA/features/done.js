// features/done.js
const { hiyaok, styleMessage } = require('../utils/messages');
const { isAdmin } = require('../utils/admin');

const done = async (sock, msg) => {
  try {
    const { messages } = msg;
    const message = messages[0];
    const { remoteJid, participant } = message.key;
    
    // Check if sender is admin
    const sender = participant || remoteJid;
    if (!isAdmin(sender)) {
      await hiyaok.reply(sock, remoteJid, 'Maaf, fitur ini hanya untuk admin.', message, { style: 'error' });
      return;
    }
    
    // Get message text
    const msgText = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
    
    // Parse order details from message (format: !done product_name price)
    const args = msgText.split(' ');
    args.shift(); // Remove the command itself
    
    // Check if it's a reply to an order
    const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const quotedJid = message.message?.extendedTextMessage?.contextInfo?.participant;
    
    if (!quotedMessage && args.length < 2) {
      const usageText = `${styleMessage('CARA PENGGUNAAN', 'title')}
Gunakan command ini dengan 2 cara:

1️⃣ Reply pesan pesanan dan ketik:
   !done nama_produk harga

2️⃣ Ketik langsung:
   !done nama_produk harga

Contoh: !done Kaos Hitam 150000
${styleMessage('', 'footer')}`;
      
      await hiyaok.sendpesan(sock, remoteJid, usageText);
      return;
    }
    
    // Get product name and price
    let productName, price;
    
    if (args.length >= 2) {
      // The last argument is the price
      price = args.pop();
      // The rest is the product name
      productName = args.join(' ');
    } else {
      await hiyaok.reply(sock, remoteJid, '❌ Format tidak valid. Gunakan: !done nama_produk harga', message, { style: 'error' });
      return;
    }
    
    // Format price
    price = parseInt(price.replace(/[^\d]/g, ''));
    if (isNaN(price)) {
      await hiyaok.reply(sock, remoteJid, '❌ Harga tidak valid. Gunakan angka saja.', message, { style: 'error' });
      return;
    }
    
    // Send completion message to customer
    const doneMessage = `${styleMessage('PESANAN SELESAI', 'title')}
✅ Pesanan Anda telah selesai diproses.

📦 Produk: ${productName}
💰 Harga: Rp${price.toLocaleString('id-ID')}
⏰ Waktu Selesai: ${new Date().toLocaleString('id-ID')}

Terima kasih telah berbelanja! 🙏
${styleMessage('', 'footer')}`;
    
    if (quotedJid) {
      await hiyaok.sendpesan(sock, quotedJid, doneMessage);
      
      // Confirmation to admin
      await hiyaok.reply(sock, remoteJid, `Notifikasi "Pesanan Selesai" untuk ${productName} telah dikirim ke pelanggan.`, message, { style: 'success' });
    } else {
      // If not a reply, ask for the customer's number
      await hiyaok.reply(sock, remoteJid, 'Silahkan ketik nomor pelanggan yang akan dikirimkan notifikasi (format: 62xxxxxxxx):', message);
      
      // Store the done message in a global variable or state management for later use
      global.pendingDoneMessage = {
        admin: sender,
        message: doneMessage,
        product: productName,
        timestamp: new Date()
      };
    }
    
  } catch (error) {
    console.error('Error in done feature:', error);
  }
};

module.exports = done;