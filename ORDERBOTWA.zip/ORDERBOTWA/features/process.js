// features/process.js
const { hiyaok, styleMessage } = require('../utils/messages');
const { isAdmin } = require('../utils/admin');

const process = async (sock, msg) => {
  try {
    const { messages } = msg;
    const message = messages[0];
    const { remoteJid, participant } = message.key;
    
    // Check if sender is admin
    const sender = participant || remoteJid;
    if (!isAdmin(sender)) {
      await hiyaok.reply(sock, remoteJid, 'Maaf, fitur ini hanya untuk admin.', message, { style: 'error' });
      return;
    }
    
    // Get message text and check if it's a reply
    const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    
    if (!quotedMessage) {
      await hiyaok.reply(sock, remoteJid, '❌ Silahkan balas pesan pesanan yang ingin diproses.', message, { style: 'error' });
      return;
    }
    
    const quotedJid = message.message?.extendedTextMessage?.contextInfo?.participant;
    
    // Send processing message
    const processingMessage = `${styleMessage('PESANAN DIPROSES', 'title')}
Status pesanan Anda telah diperbarui menjadi "Sedang Diproses".
Mohon ditunggu, admin akan segera memproses pesanan Anda.

⏰ Waktu Proses: ${new Date().toLocaleString('id-ID')}
${styleMessage('', 'footer')}`;
    
    await hiyaok.sendpesan(sock, quotedJid, processingMessage);
    
    // Confirmation to admin
    await hiyaok.reply(sock, remoteJid, 'Notifikasi "Pesanan Diproses" telah dikirim ke pelanggan.', message, { style: 'success' });
    
  } catch (error) {
    console.error('Error in process feature:', error);
  }
};

module.exports = process;