// features/addList.js
const { Product } = require('../database/mongodb');
const { hiyaok, styleMessage } = require('../utils/messages');
const { isAdmin } = require('../utils/admin');

let addListState = {};

const addList = async (sock, msg) => {
  try {
    const { messages } = msg;
    const message = messages[0];
    const { remoteJid, participant } = message.key;
    
    // Check if sender is admin
    const sender = participant || remoteJid;
    if (!isAdmin(sender)) {
      await hiyaok.reply(sock, remoteJid, 'Maaf, fitur ini hanya untuk admin.', message, { style: 'error' });
      return;
    }
    
    // Get message text
    const msgText = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
    
    // If user is not in state, initialize the add product flow
    if (!addListState[sender]) {
      addListState[sender] = { step: 1, data: {} };
      
      const promptText = `${styleMessage('TAMBAH PRODUK BARU', 'title')}
Silahkan masukkan nama produk:
${styleMessage('', 'footer')}`;
      
      await hiyaok.sendpesan(sock, remoteJid, promptText);
      return;
    }
    
    // Handle each step of the product addition process
    switch (addListState[sender].step) {
      case 1: // Product name
        addListState[sender].data.name = msgText;
        addListState[sender].step = 2;
        
        await hiyaok.reply(sock, remoteJid, '💰 Silahkan masukkan harga produk (angka saja):', message);
        break;
        
      case 2: // Product price
        const price = parseInt(msgText.replace(/[^\d]/g, ''));
        if (isNaN(price)) {
          await hiyaok.reply(sock, remoteJid, '❌ Harga harus berupa angka. Silahkan masukkan harga produk (angka saja):', message, { style: 'error' });
          return;
        }
        
        addListState[sender].data.price = price;
        addListState[sender].step = 3;
        
        await hiyaok.reply(sock, remoteJid, '📦 Silahkan masukkan jumlah stok produk (angka saja):', message);
        break;
        
      case 3: // Product stock
        const stock = parseInt(msgText.replace(/[^\d]/g, ''));
        if (isNaN(stock)) {
          await hiyaok.reply(sock, remoteJid, '❌ Stok harus berupa angka. Silahkan masukkan jumlah stok produk (angka saja):', message, { style: 'error' });
          return;
        }
        
        addListState[sender].data.stock = stock;
        addListState[sender].step = 4;
        
        await hiyaok.reply(sock, remoteJid, '📝 Silahkan masukkan deskripsi produk (opsional, ketik "skip" jika tidak perlu):', message);
        break;
        
      case 4: // Product description
        if (msgText.toLowerCase() !== 'skip') {
          addListState[sender].data.description = msgText;
        }
        
        // Save the product to database
        try {
          const newProduct = new Product(addListState[sender].data);
          await newProduct.save();
          
          // Send success message
          const productInfo = `${styleMessage('PRODUK BERHASIL DITAMBAHKAN', 'title')}
🏷️ *Nama:* ${newProduct.name}
💰 *Harga:* Rp${newProduct.price.toLocaleString('id-ID')}
📦 *Stok:* ${newProduct.stock}
${newProduct.description ? `📝 *Deskripsi:* ${newProduct.description}` : ''}
${styleMessage('', 'footer')}`;
          
          await hiyaok.sendpesan(sock, remoteJid, productInfo);
          
        } catch (error) {
          await hiyaok.reply(sock, remoteJid, `❌ Gagal menambahkan produk: ${error.message}`, message, { style: 'error' });
        }
        
        // Reset state
        delete addListState[sender];
        break;
    }
  } catch (error) {
    console.error('Error in addList:', error);
  }
};

module.exports = { addList, addListState };