// features/caraOrder.js
const { hiyaok, styleMessage } = require('../utils/messages');
const config = require('../config/config');

const caraOrder = async (sock, msg) => {
  try {
    const { messages } = msg;
    const message = messages[0];
    const { remoteJid } = message.key;
    
    // Create stylish cara order text
    const caraOrderText = `${styleMessage('CARA ORDER', 'title')}
${styleMessage('LANGKAH-LANGKAH PEMESANAN', 'subtitle')}
1️⃣ Pilih produk dari katalog.
2️⃣ Chat bot/admin untuk cek stok
3️⃣ Lakukan pembayaran sesuai total harga.
4️⃣ Kirim bukti transfer untuk konfirmasi.
5️⃣ Pesanan diproses & dikirim sesuai estimasi.

${styleMessage('METODE PEMBAYARAN', 'subtitle')}
💳 Bank Transfer
💸 E-Wallet

${styleMessage('CUSTOMER SERVICE', 'subtitle')}
📱 Admin: +628xxxxxxxx
⏰ Jam Operasional: 08.00 - 21.00 WIB
${styleMessage('', 'footer')}`;
    
    await hiyaok.sendpesan(sock, remoteJid, caraOrderText);
    
  } catch (error) {
    console.error('Error in caraOrder:', error);
  }
};

module.exports = caraOrder;