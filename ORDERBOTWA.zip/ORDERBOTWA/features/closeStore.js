// features/closeStore.js
const { Setting } = require('../database/mongodb');
const { hiyaok, styleMessage } = require('../utils/messages');
const { isAdmin } = require('../utils/admin');
const config = require('../config/config');

const closeStore = async (sock, msg) => {
  try {
    const { messages } = msg;
    const message = messages[0];
    const { remoteJid, participant } = message.key;
    
    // Check if sender is admin
    const sender = participant || remoteJid;
    if (!isAdmin(sender)) {
      await hiyaok.reply(sock, remoteJid, 'Maaf, fitur ini hanya untuk admin.', message, { style: 'error' });
      return;
    }
    
    // Check if store is already closed
    if (config.storeStatus === 'closed') {
      await hiyaok.reply(sock, remoteJid, 'Toko sudah dalam keadaan tutup.', message, { style: 'info' });
      return;
    }
    
    // Update store status
    config.storeStatus = 'closed';
    
    // Save to database
    await Setting.findOneAndUpdate(
      { key: 'storeStatus' },
      { value: 'closed' },
      { upsert: true }
    );
    
    // Send confirmation
    const closeMessage = `${styleMessage('TOKO DITUTUP', 'title')}
🔒 Toko ${config.storeName} telah ditutup!

Pelanggan tidak dapat memesan produk sampai toko dibuka kembali.
${styleMessage('', 'footer')}`;

    await hiyaok.sendpesan(sock, remoteJid, closeMessage);
    
  } catch (error) {
    console.error('Error in closeStore:', error);
  }
};

module.exports = closeStore;