// features/listKatalog.js
const fs = require('fs');
const { Product } = require('../database/mongodb');
const { hiyaok, formatCatalog } = require('../utils/messages');
const config = require('../config/config');

const listKatalog = async (sock, msg) => {
  try {
    const { messages } = msg;
    const message = messages[0];
    
    // Check if store is open
    const { remoteJid } = message.key;
    
    if (config.storeStatus === 'closed') {
      await hiyaok.reply(sock, remoteJid, config.storeClosedMessage, message, { style: 'warning' });
      return;
    }
    
    // Get page number from command (default is page 1)
    const args = message.message?.conversation?.split(' ') || [];
    const page = parseInt(args[1]) || 1;
    
    // Get products from database
    const products = await Product.find().sort({ createdAt: -1 });
    
    if (products.length === 0) {
      await hiyaok.reply(sock, remoteJid, '🛒 Katalog masih kosong.', message, { style: 'info' });
      return;
    }
    
    const perPage = 10;
    
    // If catalog is very long, send it as a file
    if (products.length > 50) {
      // Create a full catalog text file
      let fullCatalog = `┏━━━━━『 KATALOG PRODUK ${config.storeName} 』━━━━━┓\n\n`;
      
      products.forEach((product, index) => {
        fullCatalog += `${index + 1}. ${product.name}\n`;
        fullCatalog += `   💰 Harga: Rp${product.price.toLocaleString('id-ID')}\n`;
        fullCatalog += `   📦 Stok: ${product.stock}\n`;
        if (product.description) {
          fullCatalog += `   📝 Deskripsi: ${product.description}\n`;
        }
        fullCatalog += '\n';
      });
      
      fullCatalog += `\n┗━━━『 Total: ${products.length} Produk 』━━━┛`;
      
      // Save to file
      fs.writeFileSync('./katalog.txt', fullCatalog);
      
      // Send summary message
      await hiyaok.reply(sock, remoteJid, `📋 Katalog terlalu panjang (${products.length} produk). Mengirimkan sebagai file.`, message, { style: 'info' });
      
      // Send file
      await hiyaok.sendFile(sock, remoteJid, fs.readFileSync('./katalog.txt'), 'katalog.txt', `Katalog ${config.storeName}`);
      
      // Delete the temp file
      fs.unlinkSync('./katalog.txt');
    } else {
      // Send formatted catalog with pagination
      const catalogText = formatCatalog(products, page, perPage);
      await hiyaok.reply(sock, remoteJid, catalogText, message);
    }
  } catch (error) {
    console.error('Error in listKatalog:', error);
  }
};

module.exports = listKatalog;