// features/openStore.js
const { Setting } = require('../database/mongodb');
const { hiyaok, styleMessage } = require('../utils/messages');
const { isAdmin } = require('../utils/admin');
const config = require('../config/config');

const openStore = async (sock, msg) => {
  try {
    const { messages } = msg;
    const message = messages[0];
    const { remoteJid, participant } = message.key;
    
    // Check if sender is admin
    const sender = participant || remoteJid;
    if (!isAdmin(sender)) {
      await hiyaok.reply(sock, remoteJid, 'Maaf, fitur ini hanya untuk admin.', message, { style: 'error' });
      return;
    }
    
    // Check if store is already open
    if (config.storeStatus === 'open') {
      await hiyaok.reply(sock, remoteJid, 'Toko sudah dalam keadaan buka.', message, { style: 'info' });
      return;
    }
    
    // Update store status
    config.storeStatus = 'open';
    
    // Save to database
    await Setting.findOneAndUpdate(
      { key: 'storeStatus' },
      { value: 'open' },
      { upsert: true }
    );
    
    // Send confirmation
    const openMessage = `${styleMessage('TOKO DIBUKA', 'title')}
✅ Toko ${config.storeName} telah dibuka!

Pelanggan dapat memesan produk sekarang.
${styleMessage('', 'footer')}`;

    await hiyaok.sendpesan(sock, remoteJid, openMessage);
    
  } catch (error) {
    console.error('Error in openStore:', error);
  }
};

module.exports = openStore;