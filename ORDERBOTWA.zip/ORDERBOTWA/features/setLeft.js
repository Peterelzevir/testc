// features/setLeft.js
const { Setting, Media } = require('../database/mongodb');
const { hiyaok, styleMessage, downloadMedia } = require('../utils/messages');
const { isAdmin } = require('../utils/admin');
const config = require('../config/config');
const fs = require('fs');
const { promisify } = require('util');
const writeFileAsync = promisify(fs.writeFile);

let setLeftState = {};

const setLeft = async (sock, msg) => {
  try {
    const { messages } = msg;
    const message = messages[0];
    const { remoteJid, participant } = message.key;
    
    // Check if sender is admin
    const sender = participant || remoteJid;
    if (!isAdmin(sender)) {
      await hiyaok.reply(sock, remoteJid, 'Maaf, fitur ini hanya untuk admin.', message, { style: 'error' });
      return;
    }
    
    // Get message text
    const msgText = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
    
    // Initialize state if not already
    if (!setLeftState[sender]) {
      setLeftState[sender] = { step: 1, data: {} };
      
      const currentLeft = await Setting.findOne({ key: 'leftMessage' });
      const leftText = currentLeft ? currentLeft.value : config.leftMessage;
      
      const menuText = `${styleMessage('SET LEFT MESSAGE', 'title')}
Pesan left saat ini:

"${leftText}"

${styleMessage('PILIH JENIS LEFT MESSAGE', 'subtitle')}
1. Teks saja
2. Teks + Gambar
3. Teks + Video

Ketik nomor pilihanmu:
${styleMessage('', 'footer')}`;
      
      await hiyaok.sendpesan(sock, remoteJid, menuText);
      return;
    }
    
    // Handle the steps of setting left message
    switch (setLeftState[sender].step) {
      case 1: // Choose type
        const choice = parseInt(msgText);
        if (isNaN(choice) || choice < 1 || choice > 3) {
          await hiyaok.reply(sock, remoteJid, 'Opsi tidak valid! Silahkan pilih 1, 2, atau 3.', message, { style: 'error' });
          return;
        }
        
        setLeftState[sender].data.type = choice;
        setLeftState[sender].step = 2;
        
        if (choice === 1) {
          await hiyaok.reply(sock, remoteJid, 'Silahkan ketik pesan left baru:', message);
        } else if (choice === 2) {
          await hiyaok.reply(sock, remoteJid, 'Silahkan kirim gambar (bisa dengan caption atau tanpa):', message);
        } else if (choice === 3) {
          await hiyaok.reply(sock, remoteJid, 'Silahkan kirim video (bisa dengan caption atau tanpa):', message);
        }
        break;
        
      case 2: // Get content based on type
        try {
          const messageType = setLeftState[sender].data.type;
          
          if (messageType === 1) { // Text only
            // Update in memory config
            config.leftMessage = msgText;
            config.leftMessageType = 'text';
            
            // Save to database
            await Setting.findOneAndUpdate(
              { key: 'leftMessage' },
              { value: msgText },
              { upsert: true }
            );
            
            await Setting.findOneAndUpdate(
              { key: 'leftMessageType' },
              { value: 'text' },
              { upsert: true }
            );
            
            // Send confirmation
            await hiyaok.reply(
              sock, 
              remoteJid, 
              'Pesan left berhasil diperbarui!', 
              message,
              { style: 'success' }
            );
            
            // Preview the left message
            await hiyaok.sendpesan(
              sock,
              remoteJid,
              `${styleMessage('PREVIEW LEFT MESSAGE', 'title')}
${msgText}
${styleMessage('', 'footer')}`
            );
            
          } else if (messageType === 2 || messageType === 3) { // Image or Video
            let mediaData;
            
            // Check if there's media in the message
            if (message.message?.imageMessage) {
              mediaData = await downloadMedia(message.message);
            } else if (message.message?.videoMessage) {
              mediaData = await downloadMedia(message.message);
            } else {
              await hiyaok.reply(sock, remoteJid, 'Tidak ada media yang dikirim. Silahkan kirim gambar atau video.', message, { style: 'error' });
              return;
            }
            
            // Get caption if exists
            const caption = message.message?.imageMessage?.caption || 
                          message.message?.videoMessage?.caption || 
                          '';
            
            // Save media type and caption
            config.leftMessageType = mediaData.mediaType;
            config.leftMessage = caption;
            
            // Save settings to database
            await Setting.findOneAndUpdate(
              { key: 'leftMessageType' },
              { value: mediaData.mediaType },
              { upsert: true }
            );
            
            await Setting.findOneAndUpdate(
              { key: 'leftMessage' },
              { value: caption },
              { upsert: true }
            );
            
            // Save media to database
            // First, delete existing left media if any
            await Media.deleteOne({ type: 'left' });
            
            // Then save the new media
            const newMedia = new Media({
              type: 'left',
              mediaType: mediaData.mediaType,
              buffer: mediaData.buffer,
              caption: caption
            });
            
            await newMedia.save();
            
            // Send confirmation
            await hiyaok.reply(
              sock, 
              remoteJid, 
              `Pesan left dengan ${mediaData.mediaType} berhasil disimpan!`, 
              message,
              { style: 'success' }
            );
            
            // Preview the left message
            if (mediaData.mediaType === 'image') {
              await hiyaok.sendGambar(
                sock,
                remoteJid,
                mediaData.buffer,
                `${styleMessage('PREVIEW LEFT MESSAGE', 'title')}
${caption}
${styleMessage('', 'footer')}`
              );
            } else if (mediaData.mediaType === 'video') {
              await hiyaok.sendVideo(
                sock,
                remoteJid,
                mediaData.buffer,
                `${styleMessage('PREVIEW LEFT MESSAGE', 'title')}
${caption}
${styleMessage('', 'footer')}`
              );
            }
          }
          
        } catch (error) {
          console.error('Error setting left message:', error);
          await hiyaok.reply(sock, remoteJid, `Gagal menyimpan pesan left: ${error.message}`, message, { style: 'error' });
        }
        
        // Reset state
        delete setLeftState[sender];
        break;
    }
  } catch (error) {
    console.error('Error in setLeft:', error);
  }
};

module.exports = { setLeft, setLeftState };