// features/editList.js
const { Product } = require('../database/mongodb');
const { hiyaok, formatProduct, styleMessage } = require('../utils/messages');
const { isAdmin } = require('../utils/admin');

let editListState = {};

const editList = async (sock, msg) => {
  try {
    const { messages } = msg;
    const message = messages[0];
    const { remoteJid, participant } = message.key;
    
    // Check if sender is admin
    const sender = participant || remoteJid;
    if (!isAdmin(sender)) {
      await hiyaok.reply(sock, remoteJid, 'Maaf, fitur ini hanya untuk admin.', message, { style: 'error' });
      return;
    }
    
    // Get message text
    const msgText = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
    
    // If user is not in state, initialize the edit product flow
    if (!editListState[sender]) {
      editListState[sender] = { step: 1, data: {} };
      
      // Get all products to show options
      const products = await Product.find().sort({ createdAt: -1 });
      
      if (products.length === 0) {
        await hiyaok.reply(sock, remoteJid, '🛒 Katalog masih kosong. Tidak ada produk untuk diedit.', message, { style: 'info' });
        delete editListState[sender];
        return;
      }
      
      // Show product list
      let productList = styleMessage('EDIT PRODUK', 'title');
      productList += styleMessage('DAFTAR PRODUK', 'subtitle');
      
      products.forEach((product, index) => {
        productList += styleMessage(`${index + 1}. ${product.name}`, 'list');
        productList += `   💰 Rp${product.price.toLocaleString('id-ID')} | 📦 Stok: ${product.stock}\n`;
      });
      
      productList += '\nKetik nomor produk yang ingin diedit:';
      productList += styleMessage('', 'footer');
      
      await hiyaok.sendpesan(sock, remoteJid, productList);
      
      // Store products in state
      editListState[sender].products = products;
      return;
    }
    
    // Handle each step of the product editing process
    switch (editListState[sender].step) {
      case 1: // Select product
        const productIndex = parseInt(msgText) - 1;
        
        if (isNaN(productIndex) || productIndex < 0 || productIndex >= editListState[sender].products.length) {
          await hiyaok.reply(sock, remoteJid, '❌ Nomor produk tidak valid. Silahkan pilih nomor yang benar:', message, { style: 'error' });
          return;
        }
        
        // Store selected product
        editListState[sender].selectedProduct = editListState[sender].products[productIndex];
        editListState[sender].step = 2;
        
        // Show current product info and options
        const productInfo = formatProduct(editListState[sender].selectedProduct);
        const editOptions = `${productInfo}
${styleMessage('PILIH DATA YANG INGIN DIEDIT', 'subtitle')}
1. Nama Produk
2. Harga Produk
3. Stok Produk
4. Deskripsi Produk
5. Hapus Produk
0. Batal

Ketik nomor pilihan:`;
        
        await hiyaok.sendpesan(sock, remoteJid, editOptions);
        break;
        
      case 2: // Select edit option
        const option = parseInt(msgText);
        
        if (isNaN(option) || option < 0 || option > 5) {
          await hiyaok.reply(sock, remoteJid, '❌ Opsi tidak valid. Silahkan pilih nomor yang benar (0-5):', message, { style: 'error' });
          return;
        }
        
        // Cancel operation
        if (option === 0) {
          await hiyaok.reply(sock, remoteJid, '❌ Operasi dibatalkan.', message, { style: 'warning' });
          delete editListState[sender];
          return;
        }
        
        // Delete product
        if (option === 5) {
          try {
            await Product.findByIdAndDelete(editListState[sender].selectedProduct._id);
            await hiyaok.reply(sock, remoteJid, `✅ Produk "${editListState[sender].selectedProduct.name}" telah dihapus.`, message, { style: 'success' });
            delete editListState[sender];
            return;
          } catch (error) {
            await hiyaok.reply(sock, remoteJid, `❌ Gagal menghapus produk: ${error.message}`, message, { style: 'error' });
            delete editListState[sender];
            return;
          }
        }
        
        // Store edit option and move to next step
        editListState[sender].editOption = option;
        editListState[sender].step = 3;
        
        // Prompt for new value
        let prompt = '';
        switch (option) {
          case 1:
            prompt = '✏️ Masukkan nama produk baru:';
            break;
          case 2:
            prompt = '💰 Masukkan harga produk baru (angka saja):';
            break;
          case 3:
            prompt = '📦 Masukkan stok produk baru (angka saja):';
            break;
          case 4:
            prompt = '📝 Masukkan deskripsi produk baru:';
            break;
        }
        
        await hiyaok.reply(sock, remoteJid, prompt, message);
        break;
        
      case 3: // Input new value
        try {
          // Get selected product
          const product = await Product.findById(editListState[sender].selectedProduct._id);
          
          if (!product) {
            await hiyaok.reply(sock, remoteJid, '❌ Produk tidak ditemukan. Mungkin telah dihapus.', message, { style: 'error' });
            delete editListState[sender];
            return;
          }
          
          // Update based on selected option
          switch (editListState[sender].editOption) {
            case 1: // Name
              product.name = msgText;
              break;
            case 2: // Price
              const price = parseInt(msgText.replace(/[^\d]/g, ''));
              if (isNaN(price)) {
                await hiyaok.reply(sock, remoteJid, '❌ Harga harus berupa angka. Silahkan masukkan harga produk (angka saja):', message, { style: 'error' });
                return;
              }
              product.price = price;
              break;
            case 3: // Stock
              const stock = parseInt(msgText.replace(/[^\d]/g, ''));
              if (isNaN(stock)) {
                await hiyaok.reply(sock, remoteJid, '❌ Stok harus berupa angka. Silahkan masukkan jumlah stok produk (angka saja):', message, { style: 'error' });
                return;
              }
              product.stock = stock;
              break;
            case 4: // Description
              product.description = msgText;
              break;
          }
          
          // Save updated product
          await product.save();
          
          // Send success message
          const updatedInfo = formatProduct(product);
          const successMessage = `${styleMessage('PRODUK BERHASIL DIPERBARUI', 'title')}${updatedInfo}`;
          
          await hiyaok.sendpesan(sock, remoteJid, successMessage);
          
        } catch (error) {
          await hiyaok.reply(sock, remoteJid, `❌ Gagal memperbarui produk: ${error.message}`, message, { style: 'error' });
        }
        
        // Reset state
        delete editListState[sender];
        break;
    }
  } catch (error) {
    console.error('Error in editList:', error);
  }
};

module.exports = { editList, editListState };