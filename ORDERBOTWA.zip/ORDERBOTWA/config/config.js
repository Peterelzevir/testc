// config/config.js
const config = {
  // Bot Settings
  botName: "punyasu bot", //ganti sm nama bot mu
  prefix: ".", //ganti prefix
  
  // Store Settings
  storeName: "PUNYASU.CO🦋",
  storeStatus: "open", // open/closed
  
  // Admin Numbers ganti sm owner 
  adminNumbers: ["6285134414177"],
  
  // MongoDB Connection
  mongoURI: "mongodb+srv://petelzevir:WYeCEOCFeZaCugR2@dbstorebot.zxkde.mongodb.net/?retryWrites=true&w=majority&appName=dbstorebot", // masukin url mongodb nya kesini
  
  // Messages
  welcomeMessage: "Selamat datang di toko kami! Ketik !katalog untuk melihat produk kami.",
  welcomeMessageType: "text", // text, image, video
  welcomeMedia: null, // For storing media URLs or buffers
  
  leftMessage: "Terima kasih telah mengunjungi toko kami.",
  leftMessageType: "text", // text, image, video
  leftMedia: null, // For storing media URLs or buffers
  
  storeClosedMessage: "Maaf, toko sedang tutup. Silakan kembali nanti."
};

module.exports = config;