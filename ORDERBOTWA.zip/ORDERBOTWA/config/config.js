// config/config.js
const config = {
  // Bot Settings
  botName: "KatalogBot", //ganti sm nama bot mu
  prefix: "!", //ganti prefix
  
  // Store Settings
  storeName: "Toko Online",
  storeStatus: "open", // open/closed
  
  // Admin Numbers ganti sm owner 
  adminNumbers: ["628xxxxxxxx"],
  
  // MongoDB Connection
  mongoURI: "mongodb://localhost:27017/whatsapp-bot", // masukin url mongodb nya kesini
  
  // Messages
  welcomeMessage: "Selamat datang di toko kami! Ketik !katalog untuk melihat produk kami.",
  welcomeMessageType: "text", // text, image, video
  welcomeMedia: null, // For storing media URLs or buffers
  
  leftMessage: "Terima kasih telah mengunjungi toko kami.",
  leftMessageType: "text", // text, image, video
  leftMedia: null, // For storing media URLs or buffers
  
  storeClosedMessage: "Maaf, toko sedang tutup. Silakan kembali nanti."
};

module.exports = config;