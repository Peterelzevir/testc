// index.js
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason } = require('@whiskeysockets/baileys');
const pino = require('pino');
const { Boom } = require('@hapi/boom');
const fs = require('fs');
const path = require('path');
const chalk = require('chalk');
const figlet = require('figlet');
const { connectDB, Setting, Media } = require('./database/mongodb');
const config = require('./config/config');

//
global.crypto = require('crypto');

// Import features
const listKatalog = require('./features/listKatalog');
const { addList, addListState } = require('./features/addList');
const { editList, editListState } = require('./features/editList');
const openStore = require('./features/openStore');
const closeStore = require('./features/closeStore');
const { setWelcome, setWelcomeState } = require('./features/setWelcome');
const { setLeft, setLeftState } = require('./features/setLeft');
const process = require('./features/process');
const done = require('./features/done');
const caraOrder = require('./features/caraOrder');

// Display bot name on startup
console.log(chalk.green(figlet.textSync(config.botName, { font: 'Big' })));
console.log(chalk.yellow('----------------------------------------'));
console.log(chalk.yellow('WhatsApp Bot using @whiskeysockets/baileys'));
console.log(chalk.yellow('----------------------------------------\n'));

// Connect to MongoDB
connectDB();

async function loadSettings() {
  try {
    // Load settings from database
    const storeStatus = await Setting.findOne({ key: 'storeStatus' });
    if (storeStatus) config.storeStatus = storeStatus.value;
    
    const welcomeMessage = await Setting.findOne({ key: 'welcomeMessage' });
    if (welcomeMessage) config.welcomeMessage = welcomeMessage.value;
    
    const welcomeMessageType = await Setting.findOne({ key: 'welcomeMessageType' });
    if (welcomeMessageType) config.welcomeMessageType = welcomeMessageType.value;
    
    const leftMessage = await Setting.findOne({ key: 'leftMessage' });
    if (leftMessage) config.leftMessage = leftMessage.value;
    
    const leftMessageType = await Setting.findOne({ key: 'leftMessageType' });
    if (leftMessageType) config.leftMessageType = leftMessageType.value;
    
    console.log(chalk.green('✅ Settings loaded successfully'));
  } catch (error) {
    console.error(chalk.red('❌ Error loading settings:'), error.message);
  }
}

// Global variable for pending done messages
global.pendingDoneMessage = null;

async function startBot() {
  // Load settings from database
  await loadSettings();
  
  const { state, saveCreds } = await useMultiFileAuthState('auth_info');
  
  // Create a socket instance
  const sock = makeWASocket({
    printQRInTerminal: true,
    auth: state,
    logger: pino({ level: 'silent' })
  });
  
  // Handle connection updates
  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect } = update;
    
    if (connection === 'close') {
      const shouldReconnect = (lastDisconnect.error instanceof Boom && 
                              lastDisconnect.error.output.statusCode !== DisconnectReason.loggedOut);
      
      console.log(chalk.red('❌ Connection closed due to:'), lastDisconnect.error);
      
      if (shouldReconnect) {
        console.log(chalk.yellow('🔄 Reconnecting...'));
        startBot();
      } else {
        console.log(chalk.red('💤 Bot disconnected. Please scan QR code again.'));
      }
    }
    
    if (connection === 'open') {
      console.log(chalk.green('✅ Bot connected successfully!'));
    }
  });
  
  // Listen for credential updates
  sock.ev.on('creds.update', saveCreds);
  
  // Listen for group participant updates (join/leave)
  sock.ev.on('group-participants.update', async (event) => {
    try {
      // Handle welcome message
      if (event.action === 'add') {
        for (const participant of event.participants) {
          // Get welcome media and type from DB if it exists
          if (config.welcomeMessageType === 'text') {
            await sock.sendMessage(event.id, { 
              text: config.welcomeMessage 
            });
          } else {
            // Get media from database
            const welcomeMedia = await Media.findOne({ type: 'welcome' });
            
            if (welcomeMedia) {
              if (welcomeMedia.mediaType === 'image') {
                await sock.sendMessage(event.id, { 
                  image: welcomeMedia.buffer,
                  caption: config.welcomeMessage
                });
              } else if (welcomeMedia.mediaType === 'video') {
                await sock.sendMessage(event.id, { 
                  video: welcomeMedia.buffer,
                  caption: config.welcomeMessage
                });
              }
            } else {
              // Fallback to text if media not found
              await sock.sendMessage(event.id, { 
                text: config.welcomeMessage 
              });
            }
          }
        }
      }
      
      // Handle leave message
      if (event.action === 'remove') {
        for (const participant of event.participants) {
          // Get left media and type from DB if it exists
          if (config.leftMessageType === 'text') {
            await sock.sendMessage(event.id, { 
              text: config.leftMessage 
            });
          } else {
            // Get media from database
            const leftMedia = await Media.findOne({ type: 'left' });
            
            if (leftMedia) {
              if (leftMedia.mediaType === 'image') {
                await sock.sendMessage(event.id, { 
                  image: leftMedia.buffer,
                  caption: config.leftMessage
                });
              } else if (leftMedia.mediaType === 'video') {
                await sock.sendMessage(event.id, { 
                  video: leftMedia.buffer,
                  caption: config.leftMessage
                });
              }
            } else {
              // Fallback to text if media not found
              await sock.sendMessage(event.id, { 
                text: config.leftMessage 
              });
            }
          }
        }
      }
    } catch (error) {
      console.error('Error in group event handler:', error);
    }
  });
  
  // Process incoming messages
  sock.ev.on('messages.upsert', async (msg) => {
    try {
      if (msg.type !== 'notify') return;
      
      const message = msg.messages[0];
      
      // Skip messages without content
      if (!message.message) return;
      
      // Get message content text
      const msgText = message.message?.conversation || 
                     message.message?.extendedTextMessage?.text || 
                     message.message?.imageMessage?.caption ||
                     message.message?.videoMessage?.caption || '';
      
      // Process commands
      if (msgText.startsWith(config.prefix)) {
        const command = msgText.slice(config.prefix.length).trim().split(' ')[0].toLowerCase();
        
        switch (command) {
          case 'katalog':
          case 'list':
            await listKatalog(sock, msg);
            break;
          
          case 'addlist':
          case 'tambah':
            await addList(sock, msg);
            break;
          
          case 'editlist':
          case 'edit':
            await editList(sock, msg);
            break;
          
          case 'openstore':
          case 'buka':
            await openStore(sock, msg);
            break;
          
          case 'closestore':
          case 'tutup':
            await closeStore(sock, msg);
            break;
          
          case 'setwelcome':
            await setWelcome(sock, msg);
            break;
          
          case 'setleft':
            await setLeft(sock, msg);
            break;
          
          case 'process':
          case 'proses':
            await process(sock, msg);
            break;
          
          case 'done':
            await done(sock, msg);
            break;
          
          case 'caraorder':
          case 'order':
            await caraOrder(sock, msg);
            break;
          
          case 'help':
          case 'menu':
            // Display help menu
            const menuText = `┏━━━━━『 MENU BOT ${config.botName} 』━━━━━┓

┌──『 KATALOG 』──┐
◦ !katalog - Lihat daftar produk
◦ !caraorder - Lihat cara pemesanan

┌──『 ADMIN 』──┐
◦ !addlist - Tambah produk
◦ !editlist - Edit/hapus produk
◦ !openstore - Buka toko
◦ !closestore - Tutup toko
◦ !setwelcome - Atur pesan welcome
◦ !setleft - Atur pesan left
◦ !proses - Tandai pesanan diproses
◦ !done - Tandai pesanan selesai

┗━━━『 Created by ${config.botName} 』━━━┛`;
            await sock.sendMessage(message.key.remoteJid, { text: menuText });
            break;
        }
      } else {
        // Handle ongoing conversations if there's an active state
        const sender = message.key.participant || message.key.remoteJid;
        
        if (addListState[sender]) {
          await addList(sock, msg);
        } else if (editListState[sender]) {
          await editList(sock, msg);
        } else if (setWelcomeState[sender]) {
          await setWelcome(sock, msg);
        } else if (setLeftState[sender]) {
          await setLeft(sock, msg);
        } else if (global.pendingDoneMessage && global.pendingDoneMessage.admin === sender) {
          // Handle pending done message (when admin needs to provide customer number)
          const customerNumber = msgText.trim().replace(/[^\d]/g, '');
          
          if (customerNumber.length < 10) {
            await sock.sendMessage(message.key.remoteJid, { 
              text: '❌ Nomor tidak valid. Silahkan masukkan nomor yang benar.' 
            });
            return;
          }
          
          // Format the number with proper prefix
          const formattedNumber = customerNumber.startsWith('0') ? 
                                `62${customerNumber.slice(1)}@s.whatsapp.net` : 
                                `${customerNumber}@s.whatsapp.net`;
          
          // Send the done message to the customer
          await sock.sendMessage(formattedNumber, { 
            text: global.pendingDoneMessage.message 
          });
          
          // Confirmation to admin
          await sock.sendMessage(message.key.remoteJid, { 
            text: `✅ Notifikasi "Pesanan Selesai" untuk ${global.pendingDoneMessage.product} telah dikirim ke pelanggan.` 
          });
          
          // Clear the pending message
          global.pendingDoneMessage = null;
        }
      }
    } catch (error) {
      console.error('Error processing message:', error);
    }
  });
}

// Start the bot
startBot();